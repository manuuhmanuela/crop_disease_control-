<?php
// crop_disease_control/services.php
// Our Services - Comprehensive Agricultural Diagnostic Services

$page_title = "Our Services";
require_once __DIR__ . '/includes/header.php';
?>

<div style="background: linear-gradient(135deg, #1b5e20, #2e7d32); color: white; padding: 40px 24px; border-radius: 8px; margin-bottom: 28px; text-align: center;">
    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 10px;">Our Agricultural AI Services</h1>
    <p style="font-size: 1.05rem; max-width: 720px; margin: 0 auto; opacity: 0.95; line-height: 1.6;">
        Specialized computer vision solutions and agronomic management tools designed for Kenyan farming communities.
    </p>
</div>

<!-- Services Grid -->
<div class="grid-3" style="margin-bottom: 28px;">
    
    <div class="card" style="display: flex; flex-direction: column;">
        <div class="card-header">
            <h3 class="card-title">1. Instant Leaf Diagnosis</h3>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6; flex: 1;">
            Upload high-resolution photos of infected leaves from any smartphone or camera. 
            Our neural classification algorithms analyze surface discoloration, pustules, necrotic margins, and fungal spots to provide a verified diagnosis in seconds.
        </p>
        <div style="margin-top: 14px;">
            <a href="farmer/scan.php" class="btn btn-sm btn-primary">Start Diagnosis</a>
        </div>
    </div>

    <div class="card" style="display: flex; flex-direction: column;">
        <div class="card-header">
            <h3 class="card-title">2. Curative Prescriptions</h3>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6; flex: 1;">
            Once a disease is identified, the system outputs clear curative advice, including approved fungicides, bactericides, bio-pesticides, and emergency rogued plant management to halt field infection spreads.
        </p>
        <div style="margin-top: 14px;">
            <span class="badge badge-info">Chemical & Organic</span>
        </div>
    </div>

    <div class="card" style="display: flex; flex-direction: column;">
        <div class="card-header">
            <h3 class="card-title">3. Prevention Guidelines</h3>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6; flex: 1;">
            Receive evidence-based preventative guidelines tailored to Kenyan agro-ecological zones: recommended crop rotation schemes, spacing regulations, clean seed varieties, and soil drainage best practices.
        </p>
        <div style="margin-top: 14px;">
            <span class="badge badge-healthy">Cultural Management</span>
        </div>
    </div>

    <div class="card" style="display: flex; flex-direction: column;">
        <div class="card-header">
            <h3 class="card-title">4. Printable Field Reports</h3>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6; flex: 1;">
            Generate formal diagnostic advisory reports complete with unique reference numbers, sample images, symptoms, severity ratings, and treatment steps for physical filing or agro-dealer consultations.
        </p>
        <div style="margin-top: 14px;">
            <span class="badge badge-info">PDF & Print Ready</span>
        </div>
    </div>

    <div class="card" style="display: flex; flex-direction: column;">
        <div class="card-header">
            <h3 class="card-title">5. Historical Field Audit</h3>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6; flex: 1;">
            Farmers can track all past diagnoses chronologically. Monitor disease recurrence across seasons to evaluate the effectiveness of applied treatments and protect subsequent harvests.
        </p>
        <div style="margin-top: 14px;">
            <a href="farmer/history.php" class="btn btn-sm btn-outline">Review Scans</a>
        </div>
    </div>

    <div class="card" style="display: flex; flex-direction: column;">
        <div class="card-header">
            <h3 class="card-title">6. Knowledgebase Access</h3>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6; flex: 1;">
            Access an updated agricultural database documenting symptoms, causative pathogens, and severity indices for key crops: Maize, Tomatoes, Irish Potatoes, and Common Beans.
        </p>
        <div style="margin-top: 14px;">
            <span class="badge badge-moderate">Agronomic Library</span>
        </div>
    </div>

</div>

<!-- Call to Action Banner -->
<div class="card" style="background: #f1f8e9; border: 1px solid #c8e6c9; text-align: center; padding: 32px 20px;">
    <h3 style="color: #1b5e20; margin-bottom: 8px;">Ready to Analyze Your Crop Health?</h3>
    <p style="font-size: 0.95rem; color: #374151; max-width: 600px; margin: 0 auto 20px auto;">
        Sign in to your farmer account or register for free to begin uploading leaf images today.
    </p>
    <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
        <a href="farmer/scan.php" class="btn btn-primary">Diagnose a Leaf Now</a>
        <a href="contact.php" class="btn btn-outline">Contact Agronomic Support</a>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
