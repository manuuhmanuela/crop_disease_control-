<?php
// crop_disease_control/login.php
// User Login for Farmers and Administrators

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    if ($_SESSION['user_role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: farmer/dashboard.php");
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both your email address and password.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user_record = $stmt->fetch();

            // Support both direct plain text comparison and hash fallback
            $is_authenticated = false;
            if ($user_record) {
                if ($password === $user_record['password'] || password_verify($password, $user_record['password'])) {
                    $is_authenticated = true;
                }
            }

            if ($is_authenticated) {
                // Login success
                $_SESSION['user_id'] = $user_record['id'];
                $_SESSION['user_name'] = $user_record['name'];
                $_SESSION['user_email'] = $user_record['email'];
                $_SESSION['user_role'] = $user_record['role'];
                $_SESSION['user_county'] = $user_record['county'] ?? 'Kenya';

                set_flash('success', "Welcome back, " . htmlspecialchars($user_record['name']) . ".");

                if ($user_record['role'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } else {
                    header("Location: farmer/dashboard.php");
                }
                exit;
            } else {
                $error = 'Invalid email address or password. Please try again.';
            }
        } catch (PDOException $e) {
            $error = 'Database authentication error: ' . $e->getMessage();
        }
    }
}

$page_title = "Sign In";
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 460px; margin: 30px auto;">
    <div class="card">
        <div class="card-header" style="text-align: center; display: block;">
            <h2 class="card-title" style="margin-bottom: 4px;">Sign In to Your Account</h2>
            <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
                Farmer and Administrator Portal
            </p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label class="form-label" for="email">Email Address</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="user@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required autofocus>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block" style="padding: 12px; font-size: 1rem; margin-top: 10px;">
                Sign In
            </button>
        </form>

        <!-- Test Credentials Box -->
        <div style="margin-top: 24px; padding: 14px; background: #f1f8e9; border: 1px solid #c8e6c9; border-radius: 6px; font-size: 0.84rem;">
            <div style="font-weight: 700; color: #2e7d32; margin-bottom: 6px;">Demo Test Credentials:</div>
            <div style="margin-bottom: 4px;">
                <strong>Administrator:</strong> <code>admin@cropai.ke</code> / <code>admin123</code>
            </div>
            <div>
                <strong>Farmer:</strong> <code>catherine@farmer.ke</code> / <code>farmer123</code>
            </div>
        </div>

        <div style="text-align: center; margin-top: 18px; font-size: 0.9rem; color: var(--text-muted); border-top: 1px solid var(--border); padding-top: 14px;">
            Do not have an account yet? <a href="register.php" style="color: var(--primary); font-weight: 600;">Register as Farmer</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
