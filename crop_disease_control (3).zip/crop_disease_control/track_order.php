<?php
// crop_disease_control/track_order.php
// Public and Farmer Order Tracking Interface

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

$search_query = sanitize($_GET['order_number'] ?? '');
$order = null;
$items = [];
$error_msg = '';

if (!empty($search_query)) {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM `orders` 
            WHERE `order_number` = ? OR `tracking_number` = ? OR `shipping_phone` = ?
            ORDER BY `id` DESC LIMIT 1
        ");
        $stmt->execute([$search_query, $search_query, $search_query]);
        $order = $stmt->fetch();

        if ($order) {
            $stmt_items = $pdo->prepare("SELECT * FROM `order_items` WHERE `order_id` = ?");
            $stmt_items->execute([$order['id']]);
            $items = $stmt_items->fetchAll();
        } else {
            $error_msg = "No order found matching '{$search_query}'. Please check your order reference or tracking number.";
        }
    } catch (PDOException $e) {
        $error_msg = "Database query error: " . $e->getMessage();
    }
}

$page_title = "Track Order";
require_once __DIR__ . '/includes/header.php';

// Map status to progress step (1 to 4)
$step_level = 1;
if ($order) {
    switch ($order['order_status']) {
        case 'Pending':
            $step_level = 1;
            break;
        case 'Processing':
            $step_level = 2;
            break;
        case 'Dispatched':
            $step_level = 3;
            break;
        case 'Delivered':
            $step_level = 4;
            break;
        case 'Cancelled':
            $step_level = 0;
            break;
    }
}
?>

<div style="max-width: 820px; margin: 0 auto;">

    <div style="text-align: center; margin-bottom: 24px;">
        <h1 class="card-title" style="font-size: 1.8rem; margin-bottom: 6px;">Consignment & Order Tracking</h1>
        <p style="font-size: 0.92rem; color: var(--text-muted); margin: 0;">
            Check the real-time fulfillment and delivery status of your agro-chemical products.
        </p>
    </div>

    <!-- Search Form -->
    <div class="card" style="padding: 24px; margin-bottom: 24px;">
        <form method="GET" action="track_order.php" style="display: flex; gap: 10px; flex-wrap: wrap;">
            <input type="text" name="order_number" class="form-control" placeholder="Enter Order Number (e.g. ORD-2026-8812) or Tracking Code..." value="<?php echo htmlspecialchars($search_query); ?>" style="flex: 1; min-width: 250px;" required>
            <button type="submit" class="btn btn-primary">Track Order</button>
        </form>
        <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 8px;">
            Demo Reference to test: <code>ORD-2026-8812</code>
        </div>
    </div>

    <?php if ($error_msg): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>

    <?php if ($order): ?>
        <!-- Order Progress Card -->
        <div class="card" style="border-top: 4px solid var(--primary); padding: 28px;">
            
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px; margin-bottom: 24px;">
                <div>
                    <span style="font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted); font-weight: 600;">Tracking Order:</span>
                    <h2 style="color: var(--primary-dark); font-size: 1.45rem; margin: 2px 0;">
                        <?php echo htmlspecialchars($order['order_number']); ?>
                    </h2>
                    <div style="font-size: 0.85rem; color: var(--text-muted);">
                        Tracking ID: <strong><?php echo htmlspecialchars($order['tracking_number']); ?></strong> &bull; Destination: <strong><?php echo htmlspecialchars($order['shipping_county']); ?>, Kenya</strong>
                    </div>
                </div>

                <div style="text-align: right;">
                    <span class="badge badge-<?php echo $order['order_status'] === 'Delivered' ? 'healthy' : 'info'; ?>" style="font-size: 0.9rem; padding: 6px 14px;">
                        Status: <?php echo htmlspecialchars($order['order_status']); ?>
                    </span>
                    <div style="font-size: 0.82rem; color: var(--text-muted); margin-top: 4px;">
                        Placed: <?php echo date('M d, Y', strtotime($order['created_at'])); ?>
                    </div>
                </div>
            </div>

            <!-- Visual Progress Tracker -->
            <div style="margin: 32px 0 24px 0;">
                <div style="display: flex; justify-content: space-between; position: relative;">
                    
                    <!-- Progress Bar Background Line -->
                    <div style="position: absolute; top: 15px; left: 10%; right: 10%; height: 4px; background: #e2e8f0; z-index: 1;">
                        <div style="height: 100%; background: var(--primary); width: <?php echo ($step_level >= 4 ? 100 : ($step_level >= 3 ? 66 : ($step_level >= 2 ? 33 : 0))); ?>%; transition: width 0.3s;"></div>
                    </div>

                    <!-- Step 1 -->
                    <div style="text-align: center; position: relative; z-index: 2; flex: 1;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; margin: 0 auto 8px auto; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem; <?php echo $step_level >= 1 ? 'background: var(--primary); color: #fff;' : 'background: #e2e8f0; color: #64748b;'; ?>">
                            1
                        </div>
                        <div style="font-size: 0.82rem; font-weight: 600;">Order Placed</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">Received</div>
                    </div>

                    <!-- Step 2 -->
                    <div style="text-align: center; position: relative; z-index: 2; flex: 1;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; margin: 0 auto 8px auto; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem; <?php echo $step_level >= 2 ? 'background: var(--primary); color: #fff;' : 'background: #e2e8f0; color: #64748b;'; ?>">
                            2
                        </div>
                        <div style="font-size: 0.82rem; font-weight: 600;">Processing</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">Packaged</div>
                    </div>

                    <!-- Step 3 -->
                    <div style="text-align: center; position: relative; z-index: 2; flex: 1;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; margin: 0 auto 8px auto; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem; <?php echo $step_level >= 3 ? 'background: var(--primary); color: #fff;' : 'background: #e2e8f0; color: #64748b;'; ?>">
                            3
                        </div>
                        <div style="font-size: 0.82rem; font-weight: 600;">Dispatched</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">In Transit</div>
                    </div>

                    <!-- Step 4 -->
                    <div style="text-align: center; position: relative; z-index: 2; flex: 1;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; margin: 0 auto 8px auto; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem; <?php echo $step_level >= 4 ? 'background: var(--primary); color: #fff;' : 'background: #e2e8f0; color: #64748b;'; ?>">
                            4
                        </div>
                        <div style="font-size: 0.82rem; font-weight: 600;">Delivered</div>
                        <div style="font-size: 0.75rem; color: var(--text-muted);">Arrival</div>
                    </div>

                </div>
            </div>

            <!-- Delivery Details Box -->
            <div class="grid-2" style="background: #f8fafc; border: 1px solid var(--border); border-radius: 6px; padding: 16px; margin-bottom: 20px;">
                <div>
                    <h4 style="font-size: 0.88rem; color: var(--secondary); text-transform: uppercase; margin-bottom: 6px;">Consignee Information</h4>
                    <div style="font-size: 0.88rem; line-height: 1.6;">
                        <div><strong>Name:</strong> <?php echo htmlspecialchars($order['shipping_name']); ?></div>
                        <div><strong>Phone:</strong> <?php echo htmlspecialchars($order['shipping_phone']); ?></div>
                        <div><strong>Destination:</strong> <?php echo htmlspecialchars($order['shipping_address']); ?>, <?php echo htmlspecialchars($order['shipping_county']); ?></div>
                    </div>
                </div>

                <div>
                    <h4 style="font-size: 0.88rem; color: var(--secondary); text-transform: uppercase; margin-bottom: 6px;">Payment Verification</h4>
                    <div style="font-size: 0.88rem; line-height: 1.6;">
                        <div><strong>Method:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></div>
                        <div>
                            <strong>Status:</strong> 
                            <span class="badge badge-<?php echo $order['payment_status'] === 'Paid' ? 'healthy' : 'moderate'; ?>">
                                <?php echo htmlspecialchars($order['payment_status']); ?>
                            </span>
                        </div>
                        <div><strong>Total Billed:</strong> KSh <?php echo number_format($order['total_amount'], 2); ?></div>
                    </div>
                </div>
            </div>

            <!-- Items In Order -->
            <h4 style="color: var(--primary-dark); margin-bottom: 8px;">Consignment Package Contents:</h4>
            <div class="table-responsive" style="margin-bottom: 20px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Unit Price</th>
                            <th>Qty</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td>KSh <?php echo number_format($item['price'], 2); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><strong>KSh <?php echo number_format($item['subtotal'], 2); ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 10px;">
                <a href="order_success.php?id=<?php echo $order['id']; ?>" class="btn btn-outline btn-sm">View Full Receipt</a>
            </div>

        </div>
    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
