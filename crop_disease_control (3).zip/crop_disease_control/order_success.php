<?php
// crop_disease_control/order_success.php
// Order Confirmation and Receipt Display

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

$order_id = (int)($_GET['id'] ?? 0);

if (!$order_id) {
    header("Location: shop.php");
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM `orders` WHERE `id` = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();

    if (!$order) {
        die("Order record not found.");
    }

    $stmt_items = $pdo->prepare("SELECT * FROM `order_items` WHERE `order_id` = ?");
    $stmt_items->execute([$order_id]);
    $items = $stmt_items->fetchAll();

} catch (PDOException $e) {
    die("Database query error: " . $e->getMessage());
}

$page_title = "Order Confirmed - " . $order['order_number'];
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 780px; margin: 0 auto;">

    <!-- Action Bar (Hidden when printing) -->
    <div class="no-print" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <a href="shop.php" class="btn btn-outline btn-sm">Continue Shopping</a>
        <div style="display: flex; gap: 8px;">
            <a href="track_order.php?order_number=<?php echo urlencode($order['order_number']); ?>" class="btn btn-outline btn-sm">
                Track Order
            </a>
            <button onclick="window.print()" class="btn btn-primary btn-sm">
                Print Receipt
            </button>
        </div>
    </div>

    <!-- Official Order Receipt Card -->
    <div class="card" style="padding: 32px; border-top: 4px solid var(--primary); background: #ffffff;">
        
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid var(--border); padding-bottom: 16px; margin-bottom: 20px; flex-wrap: wrap; gap: 15px;">
            <div>
                <span class="badge badge-success" style="font-size: 0.85rem; margin-bottom: 6px;">Order Successfully Placed</span>
                <h2 style="color: var(--primary-dark); font-size: 1.5rem; margin: 0;">AgriShield Agro-Chemical Invoice</h2>
                <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">
                    Order Reference: <strong><?php echo htmlspecialchars($order['order_number']); ?></strong>
                </div>
            </div>
            <div style="text-align: right; font-size: 0.88rem;">
                <div><strong>Order Date:</strong> <?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?></div>
                <div><strong>Tracking Code:</strong> <code><?php echo htmlspecialchars($order['tracking_number']); ?></code></div>
            </div>
        </div>

        <!-- Destination & Payment Status -->
        <div class="grid-2" style="margin-bottom: 24px; background: #f8fafc; border: 1px solid var(--border); border-radius: 6px; padding: 16px;">
            <div>
                <h4 style="color: var(--secondary); font-size: 0.88rem; text-transform: uppercase; margin-bottom: 6px;">Consignee Destination:</h4>
                <div style="font-size: 0.9rem; line-height: 1.6;">
                    <div><strong>Recipient:</strong> <?php echo htmlspecialchars($order['shipping_name']); ?></div>
                    <div><strong>Phone:</strong> <?php echo htmlspecialchars($order['shipping_phone']); ?></div>
                    <div><strong>County:</strong> <?php echo htmlspecialchars($order['shipping_county']); ?>, Kenya</div>
                    <div><strong>Address:</strong> <?php echo htmlspecialchars($order['shipping_address']); ?></div>
                </div>
            </div>

            <div>
                <h4 style="color: var(--secondary); font-size: 0.88rem; text-transform: uppercase; margin-bottom: 6px;">Payment & Fulfillment:</h4>
                <div style="font-size: 0.9rem; line-height: 1.6;">
                    <div><strong>Payment Method:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></div>
                    <div>
                        <strong>Payment Status:</strong> 
                        <span class="badge badge-<?php echo $order['payment_status'] === 'Paid' ? 'healthy' : 'moderate'; ?>">
                            <?php echo htmlspecialchars($order['payment_status']); ?>
                        </span>
                    </div>
                    <div>
                        <strong>Dispatch Status:</strong> 
                        <span class="badge badge-info">
                            <?php echo htmlspecialchars($order['order_status']); ?>
                        </span>
                    </div>
                    <?php if (!empty($order['notes'])): ?>
                        <div style="font-size: 0.82rem; color: var(--text-muted); margin-top: 4px;">
                            Notes: <?php echo htmlspecialchars($order['notes']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Ordered Items Table -->
        <h4 style="color: var(--primary-dark); margin-bottom: 10px;">Ordered Crop Protection Items:</h4>
        <div class="table-responsive" style="margin-bottom: 20px;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product Description</th>
                        <th>Unit Price</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($item['product_name']); ?></strong></td>
                            <td>KSh <?php echo number_format($item['price'], 2); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td><strong>KSh <?php echo number_format($item['subtotal'], 2); ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Calculation Breakdown -->
        <div style="max-width: 300px; margin-left: auto; margin-bottom: 24px; font-size: 0.92rem; line-height: 1.8;">
            <div style="display: flex; justify-content: space-between;">
                <span>Products Subtotal:</span>
                <span>KSh <?php echo number_format($order['total_amount'] - $order['shipping_fee'], 2); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span>Countrywide Delivery:</span>
                <span>KSh <?php echo number_format($order['shipping_fee'], 2); ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 1.15rem; font-weight: 800; border-top: 1px solid var(--border); padding-top: 6px; margin-top: 6px; color: var(--primary-dark);">
                <span>Total Amount:</span>
                <span>KSh <?php echo number_format($order['total_amount'], 2); ?></span>
            </div>
        </div>

        <div style="border-top: 1px dashed var(--border); padding-top: 14px; text-align: center; font-size: 0.82rem; color: var(--text-muted);">
            Thank you for partnering with AgriShield AI &bull; Mount Kenya University Agricultural Support Initiative &bull; Keep your order number handy for dispatch tracking.
        </div>

    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
