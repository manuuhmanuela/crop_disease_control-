-- Database Schema for AI-Based Crop Disease Detection & Agro-Control System
-- Mount Kenya University Project Proposal by Catherine Waringa (CIT/2025/46919)

CREATE DATABASE IF NOT EXISTS `crop_disease_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `crop_disease_db`;

-- 1. Users Table (Plaintext passwords enabled)
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `county` VARCHAR(60) DEFAULT 'Nakuru',
  `role` ENUM('farmer', 'admin') DEFAULT 'farmer',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Diseases Knowledgebase Table
CREATE TABLE IF NOT EXISTS `diseases` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `crop_name` VARCHAR(50) NOT NULL,
  `disease_name` VARCHAR(120) NOT NULL,
  `symptoms` TEXT NOT NULL,
  `causes` TEXT NOT NULL,
  `treatment` TEXT NOT NULL,
  `prevention` TEXT NOT NULL,
  `severity` ENUM('Healthy', 'Low', 'Moderate', 'Severe') DEFAULT 'Moderate',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Images Uploaded Table
CREATE TABLE IF NOT EXISTS `images` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `image_path` VARCHAR(255) NOT NULL,
  `crop_type` VARCHAR(50) NOT NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_images_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Predictions / Diagnosis Table
CREATE TABLE IF NOT EXISTS `predictions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `image_id` INT NOT NULL,
  `disease_id` INT NOT NULL,
  `confidence` DECIMAL(5,2) NOT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_predictions_image` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_predictions_disease` FOREIGN KEY (`disease_id`) REFERENCES `diseases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Agro-Chemical & Disease Control Products Table
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `category` ENUM('Fungicide', 'Insecticide', 'Bio-Pesticide', 'Equipment', 'Fertilizer') NOT NULL DEFAULT 'Fungicide',
  `target_crop` VARCHAR(100) NOT NULL DEFAULT 'All Crops',
  `target_disease` VARCHAR(150) NOT NULL DEFAULT 'General Disease Control',
  `description` TEXT NOT NULL,
  `dosage` VARCHAR(150) NOT NULL DEFAULT 'Follow packaging label instructions',
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `stock_quantity` INT NOT NULL DEFAULT 50,
  `image_path` VARCHAR(255) DEFAULT 'assets/uploads/product_default.png',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Customer Orders Table
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_number` VARCHAR(30) NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `total_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `shipping_fee` DECIMAL(10,2) NOT NULL DEFAULT 250.00,
  `payment_method` ENUM('M-Pesa', 'Cash on Delivery', 'Bank Card') NOT NULL DEFAULT 'M-Pesa',
  `payment_status` ENUM('Pending', 'Paid', 'Failed') NOT NULL DEFAULT 'Pending',
  `order_status` ENUM('Pending', 'Processing', 'Dispatched', 'Delivered', 'Cancelled') NOT NULL DEFAULT 'Pending',
  `shipping_name` VARCHAR(100) NOT NULL,
  `shipping_phone` VARCHAR(30) NOT NULL,
  `shipping_county` VARCHAR(60) NOT NULL,
  `shipping_address` VARCHAR(255) NOT NULL,
  `tracking_number` VARCHAR(50) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Order Items Table
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `product_name` VARCHAR(150) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `subtotal` DECIMAL(10,2) NOT NULL,
  CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Contact & Farmer Support Messages Table
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(30) DEFAULT NULL,
  `subject` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('New', 'Read', 'Replied') NOT NULL DEFAULT 'New',
  `admin_notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. System Settings Table
CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting_key` VARCHAR(50) PRIMARY KEY,
  `setting_value` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed Settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'AgriShield AI Crop Protection'),
('support_phone', '+254 712 345 678'),
('support_email', 'support@cropai.ke'),
('shipping_flat_rate', '250.00'),
('mpesa_till_number', '5829104')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);

-- Seed Diseases Dataset (Maize, Tomatoes, Potatoes, Beans)
INSERT INTO `diseases` (`crop_name`, `disease_name`, `symptoms`, `causes`, `treatment`, `prevention`, `severity`) VALUES
('Maize', 'Healthy Maize Leaf', 'Leaves are vibrant green, free from spots, streaks, or necrotic margins. Vigorous leaf tissue with standard venation.', 'N/A - Plant is in optimum physiological health.', 'No chemical or curative treatment required. Maintain balanced nitrogen, phosphorus, and potassium fertilization.', 'Adhere to recommended spacing, weed management, and routine moisture monitoring.', 'Healthy'),

('Maize', 'Maize Lethal Necrosis Disease (MLND)', 'Chlorotic mottle on young leaves, drying of leaf margins leading to general necrosis ("scorched" appearance), premature plant death, and aborted cobs.', 'Synergistic co-infection of Maize Chlorotic Mottle Virus (MCMV) and potyviruses (such as Sugarcane Mosaic Virus), spread by vector thrips, rootworms, and aphids.', 'Uproot and burn infected plants immediately to prevent pathogen spread. Apply approved insecticides (e.g. pyrethroids or neonicotinoids) to suppress vector populations.', 'Use certified disease-free hybrid seed varieties. Practice crop rotation with non-cereal crops such as beans and sweet potatoes. Observe a closed maize season.', 'Severe'),

('Maize', 'Common Rust (Puccinia sorghi)', 'Small, powdery golden-brown to cinnamon-brown pustules erupting on both upper and lower leaf surfaces, which turn black as foliage matures.', 'Fungus Puccinia sorghi, favored by cool temperatures (16-25 C), high relative humidity (above 95%), and extended leaf wetness.', 'Apply triazole or strobilurin-based fungicides (such as Azoxystrobin + Difenoconazole) early during vegetative stages if rust covers more than 5% of canopy.', 'Plant rust-resistant hybrids. Avoid excess overhead irrigation. Ensure early planting to avoid peak fungal spore dispersal.', 'Moderate'),

('Maize', 'Northern Corn Leaf Blight (Exserohilum turcicum)', 'Long, elliptical, grayish-green or tan lesions (1-6 inches long) shaped like cigars on mature leaves. Lesions coalesce causing broad foliage death.', 'Fungus Exserohilum turcicum, overwintering in infected crop debris; favored by moderate temperatures (18-27 C) and persistent dew.', 'Foliar application of registered fungicides (e.g., Mancozeb or Pyraclostrobin) upon early appearance of lesions before tasseling stage.', 'Deep tillage to bury infected crop residue. Rotate fields with non-grasses. Plant tolerant hybrid seeds.', 'Moderate'),

('Tomato', 'Healthy Tomato Leaf', 'Deep green uniform foliage with crisp serrated margins, flexible stems, and no spots, yellowing, or viral curling.', 'N/A - Optimum plant health.', 'No fungicide or bactericide treatment required. Keep pruning suckers clean and maintain drip irrigation.', 'Mulch soil surface, maintain soil pH 6.0-6.8, and ensure proper staking for air circulation.', 'Healthy'),

('Tomato', 'Tomato Early Blight (Alternaria solani)', 'Small dark brown to black spots on older lower leaves, developing concentric rings resembling a target board, surrounded by yellow halos.', 'Fungal pathogen Alternaria solani, thriving in warm, damp weather (24-29 C) and splashing rain or overhead irrigation.', 'Remove affected bottom leaves immediately. Spray protective fungicides such as Mancozeb, Chlorothalonil, or copper hydroxide every 7-10 days.', 'Stake plants to keep foliage off soil. Apply clean straw or plastic mulch. Practice 3-year crop rotation with non-solanaceous crops.', 'Moderate'),

('Tomato', 'Tomato Late Blight (Phytophthora infestans)', 'Large, water-soaked irregularly shaped greenish-black lesions on leaves and stems. Rapid collapse of foliage with white fungal growth on leaf undersides in humid conditions.', 'Oomycete pathogen Phytophthora infestans, spreading catastrophically in cool (15-20 C), continuously wet and foggy conditions.', 'Promptly spray systemic fungicides like Metalaxyl-M + Mancozeb (Ridomil Gold) or Cymoxanil. Destroy severely affected plants immediately.', 'Use certified clean transplants. Avoid sprinkler irrigation. Ensure wide plant spacing for rapid canopy drying.', 'Severe'),

('Tomato', 'Tomato Leaf Curl Virus (TYLCV)', 'Severe upward curling and cupping of leaflets, marked yellowing (chlorosis) of leaf margins, stunted bushy growth, and severe blossom drop.', 'Tomato Yellow Leaf Curl Geminivirus, transmitted by the sweet potato whitefly (Bemisia tabaci).', 'No curative chemical cure exists for viral infection. Rogue out and destroy diseased plants. Spray insecticidal soaps, neem oil, or Imidacloprid to control whiteflies.', 'Install yellow sticky traps. Use fine insect-proof mesh netting in nursery beds. Plant resistant hybrid tomato varieties.', 'Severe'),

('Potato', 'Healthy Potato Leaf', 'Lush green compound foliage with smooth textured leaflets, uniform leaf color, and zero necrotic spots or wilting.', 'N/A - Plant is healthy and growing vigorously.', 'Maintain balanced N-P-K fertilizer and hilling up without damaging tuber roots.', 'Practice proper field drainage and regular pest monitoring for Colorado potato beetle or aphids.', 'Healthy'),

('Potato', 'Potato Late Blight (Phytophthora infestans)', 'Water-soaked brown to black lesions starting at leaf tips and margins, rapidly expanding with cottony white mildew on leaf undersides during cool damp mornings.', 'Oomycete pathogen Phytophthora infestans. Spores are transported by wind and rain splash.', 'Apply curative systemic fungicides such as Metalaxyl or Dimethomorph combined with contact protectants (Mancozeb) upon first sign.', 'Plant certified disease-free seed tubers. Hill up well to protect developing tubers from washing spores. Destroy volunteer potato plants.', 'Severe'),

('Potato', 'Potato Early Blight (Alternaria solani)', 'Concentric target-like circular dark brown necrotic spots primarily on older leaves. Leaves turn chlorotic yellow and drop prematurely.', 'Fungus Alternaria solani, often attacking plants stressed by low nitrogen, drought, or heavy tuber bulking.', 'Apply contact fungicides such as Copper Oxychloride or Mancozeb. Ensure adequate plant nutrition.', 'Avoid overhead sprinkler watering late in the day. Rotate crops with cereals or legumes. Remove harvest residues.', 'Moderate'),

('Beans', 'Healthy Bean Leaf', 'Vivid emerald green trifoliate leaves, firm stems, clear venation, and absence of rust pustules or sunken anthracnose lesions.', 'N/A - Optimal bean crop vitality.', 'Maintain soil moisture during flowering and pod filling. Keep field free of weeds.', 'Use certified seeds, intercrop appropriately with maize, and inspect regularly.', 'Healthy'),

('Beans', 'Bean Rust (Uromyces appendiculatus)', 'Small, raised reddish-brown or rust-colored powdery pustules on both leaf surfaces, surrounded by a faint yellow halo, causing premature leaf fall.', 'Fungus Uromyces appendiculatus, favored by moderate temperatures (17-22 C) and high humidity or overnight dew.', 'Spray systemic triazole fungicides (such as Tebuconazole or Propiconazole) or protective sulfur/copper sprays at early flowering.', 'Rotate crops away from legumes for at least two seasons. Bury crop residues after harvest. Plant rust-tolerant varieties.', 'Moderate'),

('Beans', 'Bean Anthracnose (Colletotrichum lindemuthianum)', 'Dark brown to black sunken elongated lesions on leaf veins on the underside of leaves, and sunken circular cankers with dark margins on pods.', 'Fungus Colletotrichum lindemuthianum, primarily seed-borne and splashed during rainfall in cool, wet environments (13-26 C).', 'Spray systemic fungicides (such as Benomyl or Carbendazim) or protective Mancozeb. Discard infected pods and plants.', 'Plant certified pathogen-free seeds. Never work or weed in wet bean fields to prevent mechanical transmission. Practice 2-year crop rotation.', 'Severe');

-- Seed Pest & Disease Control Products for Kenyan Agriculture
INSERT INTO `products` (`name`, `category`, `target_crop`, `target_disease`, `description`, `dosage`, `price`, `stock_quantity`, `image_path`) VALUES
('Ridomil Gold MZ 68 WG (500g)', 'Fungicide', 'Tomato, Potato', 'Late Blight, Downy Mildew', 'Systemic and contact fungicide offering robust preventative and curative action against Phytophthora infestans.', '50g per 20 Litre knapsack sprayer', 1650.00, 45, 'assets/uploads/prod_ridomil.png'),

('Oshothane Mancozeb 80 WP (1kg)', 'Fungicide', 'Maize, Tomato, Potato, Beans', 'Early Blight, Late Blight, Rust, Anthracnose', 'Broad-spectrum protective contact fungicide with zinc and manganese, forming a protective barrier on leaves.', '40g to 50g per 20 Litre sprayer', 950.00, 80, 'assets/uploads/prod_mancozeb.png'),

('Score 250 EC Difenoconazole (100ml)', 'Fungicide', 'Maize, Beans', 'Common Rust, Leaf Blight, Anthracnose', 'Fast-acting systemic triazole fungicide providing translaminar distribution throughout leaf tissue.', '10ml to 15ml per 20 Litre knapsack', 1250.00, 35, 'assets/uploads/prod_score.png'),

('Actara 25 WG Thiamethoxam (100g)', 'Insecticide', 'Maize, Tomato', 'MLND Vectors, Thrips, Whiteflies, Aphids', 'Systemic insecticide rapidly taken up by roots and leaves to eradicate vectors transmitting viral diseases.', '5g to 10g per 20 Litre knapsack sprayer', 1400.00, 60, 'assets/uploads/prod_actara.png'),

('Copper Oxychloride 50 WP (1kg)', 'Fungicide', 'Tomato, Potato, Beans', 'Bacterial Blight, Anthracnose, Early Blight', 'Preventative copper fungicide and bactericide suited for conventional and integrated pest management systems.', '50g per 20 Litres of clean water', 1100.00, 50, 'assets/uploads/prod_copper.png'),

('Nimbecidine Neem Bio-Pesticide (1 Litre)', 'Bio-Pesticide', 'All Crops', 'Insect Pests, Mites, Organic Disease Suppression', 'Organic cold-pressed azadirachtin extract deterring pests, disrupting feeding cycles with zero chemical residues.', '50ml per 20 Litres of water', 1850.00, 30, 'assets/uploads/prod_neem.png'),

('Manual Knapsack Sprayer 16 Litres', 'Equipment', 'All Crops', 'Application Equipment', 'Heavy-duty ergonomic pressure knapsack sprayer with adjustable cone and fan nozzles for precise leaf coverage.', 'Field spraying tool', 3400.00, 20, 'assets/uploads/prod_sprayer.png'),

('Yellow Sticky Insect Traps (Pack of 10)', 'Equipment', 'Tomato, Greenhouse', 'Whiteflies, Aphids, Thrips Monitoring', 'Non-toxic sticky traps for early population scouting and suppression of vector insects in vegetable plots.', 'Hang 1 trap per 10 square meters', 650.00, 100, 'assets/uploads/prod_traps.png');

-- Plaintext Passwords: 'admin123' and 'farmer123'
INSERT INTO `users` (`name`, `email`, `password`, `phone`, `county`, `role`) VALUES
('System Administrator', 'admin@cropai.ke', 'admin123', '+254712345678', 'Kiambu', 'admin'),
('Catherine Waringa', 'catherine@farmer.ke', 'farmer123', '+254798765432', 'Nakuru', 'farmer');

-- Seed Sample Order for Demo Farmer
INSERT INTO `orders` (`order_number`, `user_id`, `total_amount`, `shipping_fee`, `payment_method`, `payment_status`, `order_status`, `shipping_name`, `shipping_phone`, `shipping_county`, `shipping_address`, `tracking_number`, `notes`) VALUES
('ORD-2026-8812', 2, 2850.00, 250.00, 'M-Pesa', 'Paid', 'Dispatched', 'Catherine Waringa', '+254798765432', 'Nakuru', 'Njoro Sub-County, Farm Block 4', 'TRK-KE-94021', 'Leave at farm gate if unattended');

INSERT INTO `order_items` (`order_id`, `product_id`, `product_name`, `price`, `quantity`, `subtotal`) VALUES
(1, 1, 'Ridomil Gold MZ 68 WG (500g)', 1650.00, 1, 1650.00),
(1, 2, 'Oshothane Mancozeb 80 WP (1kg)', 950.00, 1, 950.00);

-- Seed Sample Contact Message
INSERT INTO `contact_messages` (`name`, `email`, `phone`, `subject`, `message`, `status`, `admin_notes`) VALUES
('Joseph Mwangi', 'joseph@farmer.ke', '+254722112233', 'Maize rust advice in Uasin Gishu', 'My hybrid maize in Eldoret is showing yellowing spots. Does Mancozeb work effectively at tasseling stage?', 'New', NULL);
