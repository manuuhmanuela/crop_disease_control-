<?php
// crop_disease_control/config/db.php
// Database configuration and connection handler

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'crop_disease_db';

try {
    // Attempt connecting to the specific database
    $pdo = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    // If database does not exist, connect to MySQL server and try auto-provisioning
    try {
        $server_pdo = new PDO("mysql:host={$db_host};charset=utf8mb4", $db_user, $db_pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        $server_pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        // Re-connect to newly created database
        $pdo = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8mb4", $db_user, $db_pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (PDOException $ex) {
        die("<div style='font-family:sans-serif;padding:25px;margin:20px auto;max-width:600px;background:#ffebee;border-left:5px solid #d32f2f;border-radius:4px;'>
            <h3 style='color:#c62828;margin-top:0;'>Database Connection Error</h3>
            <p>Could not connect to MySQL server. Please ensure XAMPP MySQL service is running.</p>
            <p><strong>Error details:</strong> " . htmlspecialchars($ex->getMessage()) . "</p>
        </div>");
    }
}

// Function to safely sanitize text input
function sanitize($input) {
    return htmlspecialchars(trim($input ?? ''), ENT_QUOTES, 'UTF-8');
}

// Helper to get base path for links
function base_url($path = '') {
    // Calculate relative path dynamically or return requested path
    return rtrim($path, '/');
}
?>
