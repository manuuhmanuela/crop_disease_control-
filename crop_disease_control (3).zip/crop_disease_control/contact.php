<?php
// crop_disease_control/contact.php
// Contact Us - Farmer Inquiries and Agronomic Support

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $message = sanitize($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_msg = 'Please fill in all required fields (Name, Email, Subject, and Message).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_msg = 'Please provide a valid email address.';
    } else {
        try {
            // Ensure table exists
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `contact_messages` (
                    `id` INT AUTO_INCREMENT PRIMARY KEY,
                    `name` VARCHAR(100) NOT NULL,
                    `email` VARCHAR(100) NOT NULL,
                    `phone` VARCHAR(30) DEFAULT NULL,
                    `subject` VARCHAR(150) NOT NULL,
                    `message` TEXT NOT NULL,
                    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");

            $stmt = $pdo->prepare("
                INSERT INTO `contact_messages` (`name`, `email`, `phone`, `subject`, `message`)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$name, $email, $phone, $subject, $message]);

            $success_msg = 'Thank you for reaching out. Your message has been received by our agricultural support team.';
            $_POST = []; // Clear form fields
        } catch (PDOException $e) {
            $error_msg = 'Could not submit your message: ' . $e->getMessage();
        }
    }
}

$page_title = "Contact Us";
require_once __DIR__ . '/includes/header.php';
?>

<div style="background: linear-gradient(135deg, #1b5e20, #2e7d32); color: white; padding: 40px 24px; border-radius: 8px; margin-bottom: 28px; text-align: center;">
    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 10px;">Contact Agronomic Support</h1>
    <p style="font-size: 1.05rem; max-width: 720px; margin: 0 auto; opacity: 0.95; line-height: 1.6;">
        Have questions regarding crop disease diagnosis, image capture guidelines, or platform access? We are here to assist.
    </p>
</div>

<div class="grid-2" style="align-items: start;">
    
    <!-- Contact Form -->
    <div class="card">
        <div class="card-header">
            <h2 class="card-title">Send Us an Inquiry</h2>
        </div>

        <?php if ($success_msg): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success_msg); ?></div>
        <?php endif; ?>

        <?php if ($error_msg): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_msg); ?></div>
        <?php endif; ?>

        <form method="POST" action="contact.php">
            <div class="form-group">
                <label class="form-label" for="name">Your Name *</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="e.g. Catherine Waringa" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label" for="email">Email Address *</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="farmer@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="phone">Phone Number</label>
                    <input type="tel" name="phone" id="phone" class="form-control" placeholder="+254 700 000 000" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="subject">Subject / Inquiry Topic *</label>
                <input type="text" name="subject" id="subject" class="form-control" placeholder="e.g. Image scanning help for Maize rust" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label" for="message">Detailed Message *</label>
                <textarea name="message" id="message" class="form-control" rows="5" placeholder="Please describe your crop symptoms, farm location, or inquiry..." required><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary btn-block" style="padding: 12px; font-size: 1rem;">
                Submit Inquiry
            </button>
        </form>
    </div>

    <!-- Contact & Institutional Info -->
    <div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Institutional Location & Desk</h3>
            </div>
            
            <div style="font-size: 0.92rem; line-height: 1.8; color: var(--text-main); margin-bottom: 20px;">
                <div style="margin-bottom: 12px;">
                    <strong>Academic Department:</strong><br>
                    School of Computing and Information Technology<br>
                    Mount Kenya University Main Campus
                </div>

                <div style="margin-bottom: 12px;">
                    <strong>Postal Address:</strong><br>
                    P.O. Box 342-01000, General Kago Road, Thika, Kenya
                </div>

                <div style="margin-bottom: 12px;">
                    <strong>Direct Research Contact:</strong><br>
                    Catherine Waringa (CIT/2025/46919)<br>
                    Email: <code>catherine@farmer.ke</code> / <code>admin@cropai.ke</code>
                </div>

                <div style="margin-bottom: 12px;">
                    <strong>Phone Support:</strong><br>
                    +254 712 345 678 / +254 798 765 432
                </div>

                <div>
                    <strong>Operating Hours:</strong><br>
                    Monday to Friday: 8:00 AM - 5:00 PM EAT<br>
                    Saturday: 9:00 AM - 1:00 PM EAT
                </div>
            </div>

            <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 6px; padding: 14px; font-size: 0.85rem; color: var(--text-muted);">
                <strong>Extension Service Note:</strong> In cases of catastrophic pest outbreak (such as Fall Armyworm or Desert Locust), please immediately contact your local Sub-County Agricultural Officer.
            </div>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
