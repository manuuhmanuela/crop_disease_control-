<?php
// crop_disease_control/farmer/dashboard.php
// Farmer Portal Dashboard

$depth = 1;
$base_prefix = '../';
$page_title = "Farmer Dashboard";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_login('../login.php');

$current_user = current_user();
$user_id = $current_user['id'];

// Get Farmer statistics
$total_scans = 0;
$infected_count = 0;
$healthy_count = 0;
$recent_scans = [];

try {
    // Total scans
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM images WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_scans = (int)$stmt->fetchColumn();

    // Infected vs Healthy
    $stmt = $pdo->prepare("
        SELECT 
            SUM(CASE WHEN d.severity = 'Healthy' THEN 1 ELSE 0 END) AS healthy_count,
            SUM(CASE WHEN d.severity != 'Healthy' THEN 1 ELSE 0 END) AS infected_count
        FROM predictions p
        JOIN images i ON p.image_id = i.id
        JOIN diseases d ON p.disease_id = d.id
        WHERE i.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $counts = $stmt->fetch();
    if ($counts) {
        $healthy_count = (int)($counts['healthy_count'] ?? 0);
        $infected_count = (int)($counts['infected_count'] ?? 0);
    }

    // Recent 5 scans
    $stmt = $pdo->prepare("
        SELECT 
            p.id AS prediction_id,
            p.confidence,
            p.created_at,
            i.image_path,
            i.crop_type,
            d.disease_name,
            d.severity
        FROM predictions p
        JOIN images i ON p.image_id = i.id
        JOIN diseases d ON p.disease_id = d.id
        WHERE i.user_id = ?
        ORDER BY p.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$user_id]);
    $recent_scans = $stmt->fetchAll();

} catch (PDOException $e) {
    $error = $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 1.8rem; color: var(--primary-dark); margin-bottom: 4px;">
            Welcome back, <?php echo htmlspecialchars($current_user['name']); ?>
        </h1>
        <p style="color: var(--text-muted); font-size: 0.95rem;">
            Farm Location: <strong><?php echo htmlspecialchars($current_user['county']); ?> County, Kenya</strong> &bull; Farmer Portal
        </p>
    </div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
        <a href="../shop.php" class="btn btn-outline" style="padding: 10px 18px; font-size: 0.95rem;">
            Buy Pest & Disease Products
        </a>
        <a href="orders.php" class="btn btn-outline" style="padding: 10px 18px; font-size: 0.95rem;">
            My Orders
        </a>
        <a href="scan.php" class="btn btn-primary" style="padding: 10px 20px; font-size: 0.95rem;">
            Start New Leaf Scan
        </a>
    </div>
</div>

<!-- Stats Overview -->
<div class="grid-3" style="margin-bottom: 28px;">
    <div class="stat-card">
        <div class="stat-icon" style="font-size: 0.9rem; font-weight: bold;">ALL</div>
        <div>
            <div class="stat-val"><?php echo $total_scans; ?></div>
            <div class="stat-label">Total Diagnoses Run</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fee2e2; color:#dc2626; font-size: 0.9rem; font-weight: bold;">DIS</div>
        <div>
            <div class="stat-val" style="color:#dc2626;"><?php echo $infected_count; ?></div>
            <div class="stat-label">Diseases Detected</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7; color:#15803d; font-size: 0.9rem; font-weight: bold;">OK</div>
        <div>
            <div class="stat-val" style="color:#15803d;"><?php echo $healthy_count; ?></div>
            <div class="stat-label">Healthy Plant Diagnoses</div>
        </div>
    </div>
</div>

<!-- Quick Guidance Banner -->
<div class="card" style="background: #f1f8e9; border: 1px solid #c8e6c9;">
    <div>
        <h4 style="color: #2e7d32; margin-bottom: 4px;">Field Tip for Accurate Image Capture</h4>
        <p style="font-size: 0.9rem; color: #374151; margin: 0;">
            For highest AI diagnostic precision, photograph a single diseased leaf in natural daylight against a plain background. 
            Ensure infected lesions, spots, or discoloration are in sharp focus.
        </p>
    </div>
</div>

<!-- Recent Diagnoses Table -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Recent Crop Diagnoses</h2>
        <a href="history.php" class="btn btn-sm btn-outline">View All History</a>
    </div>

    <?php if (empty($recent_scans)): ?>
        <div style="text-align: center; padding: 40px 20px;">
            <h3 style="color: var(--text-muted); margin-bottom: 8px;">No Diagnoses Yet</h3>
            <p style="color: var(--text-muted); font-size: 0.92rem; margin-bottom: 20px;">
                Upload your first crop leaf photo to detect infections and receive recommended treatments.
            </p>
            <a href="scan.php" class="btn btn-primary">Take Your First Scan</a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Leaf Image</th>
                        <th>Crop</th>
                        <th>AI Prediction</th>
                        <th>Confidence</th>
                        <th>Severity</th>
                        <th>Date & Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_scans as $scan): ?>
                        <tr>
                            <td>
                                <img src="../<?php echo htmlspecialchars($scan['image_path']); ?>" alt="Leaf" style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px; border: 1px solid var(--border);">
                            </td>
                            <td><strong><?php echo htmlspecialchars($scan['crop_type']); ?></strong></td>
                            <td><?php echo htmlspecialchars($scan['disease_name']); ?></td>
                            <td>
                                <strong><?php echo number_format($scan['confidence'], 1); ?>%</strong>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo strtolower($scan['severity']); ?>">
                                    <?php echo htmlspecialchars($scan['severity']); ?>
                                </span>
                            </td>
                            <td style="color: var(--text-muted); font-size: 0.88rem;">
                                <?php echo date('M d, Y h:i A', strtotime($scan['created_at'])); ?>
                            </td>
                            <td>
                                <a href="report.php?id=<?php echo $scan['prediction_id']; ?>" class="btn btn-sm btn-outline">
                                    Report
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
