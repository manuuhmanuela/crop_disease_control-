<?php
// crop_disease_control/farmer/history.php
// Farmer Diagnosis History

$depth = 1;
$base_prefix = '../';
$page_title = "My Scan History";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_login('../login.php');

$current_user = current_user();
$user_id = $current_user['id'];

// Handle delete request
if (isset($_GET['delete_id'])) {
    $del_id = (int)$_GET['delete_id'];
    try {
        $stmt_check = $pdo->prepare("
            SELECT p.id, i.image_path 
            FROM predictions p
            JOIN images i ON p.image_id = i.id
            WHERE p.id = ? AND i.user_id = ?
        ");
        $stmt_check->execute([$del_id, $user_id]);
        $record = $stmt_check->fetch();

        if ($record) {
            $file_on_disk = __DIR__ . '/../' . $record['image_path'];
            if (file_exists($file_on_disk)) {
                @unlink($file_on_disk);
            }

            $stmt_del = $pdo->prepare("DELETE FROM predictions WHERE id = ?");
            $stmt_del->execute([$del_id]);

            set_flash('success', 'Diagnosis record removed successfully.');
        } else {
            set_flash('danger', 'Record not found or access denied.');
        }
    } catch (PDOException $e) {
        set_flash('danger', 'Error deleting record: ' . $e->getMessage());
    }
    header("Location: history.php");
    exit;
}

// Filters
$filter_crop = sanitize($_GET['crop'] ?? '');
$search_query = sanitize($_GET['q'] ?? '');

$sql = "
    SELECT 
        p.id AS prediction_id,
        p.confidence,
        p.notes,
        p.created_at,
        i.image_path,
        i.crop_type,
        d.disease_name,
        d.severity
    FROM predictions p
    JOIN images i ON p.image_id = i.id
    JOIN diseases d ON p.disease_id = d.id
    WHERE i.user_id = ?
";
$params = [$user_id];

if (!empty($filter_crop)) {
    $sql .= " AND i.crop_type = ?";
    $params[] = $filter_crop;
}

if (!empty($search_query)) {
    $sql .= " AND (d.disease_name LIKE ? OR p.notes LIKE ?)";
    $params[] = "%{$search_query}%";
    $params[] = "%{$search_query}%";
}

$sql .= " ORDER BY p.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$history_records = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header" style="flex-wrap: wrap; gap: 10px;">
        <div>
            <h1 class="card-title">Diagnosis History</h1>
            <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
                All AI crop health assessments recorded for your farm.
            </p>
        </div>
        <a href="scan.php" class="btn btn-primary btn-sm">
            New Leaf Scan
        </a>
    </div>

    <!-- Filter Form -->
    <form method="GET" action="history.php" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
        <select name="crop" class="form-control" style="width: auto; min-width: 150px;" onchange="this.form.submit()">
            <option value="">All Crops</option>
            <option value="Maize" <?php echo $filter_crop === 'Maize' ? 'selected' : ''; ?>>Maize</option>
            <option value="Tomato" <?php echo $filter_crop === 'Tomato' ? 'selected' : ''; ?>>Tomato</option>
            <option value="Potato" <?php echo $filter_crop === 'Potato' ? 'selected' : ''; ?>>Potato</option>
            <option value="Beans" <?php echo $filter_crop === 'Beans' ? 'selected' : ''; ?>>Beans</option>
        </select>

        <input type="text" name="q" class="form-control" placeholder="Search disease name..." value="<?php echo htmlspecialchars($search_query); ?>" style="flex: 1; min-width: 180px;">

        <button type="submit" class="btn btn-outline btn-sm">Filter</button>
        <?php if (!empty($filter_crop) || !empty($search_query)): ?>
            <a href="history.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151;">Reset</a>
        <?php endif; ?>
    </form>

    <?php if (empty($history_records)): ?>
        <div style="text-align: center; padding: 40px 20px;">
            <h3 style="color: var(--text-muted); margin-bottom: 6px;">No Records Found</h3>
            <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 16px;">
                <?php echo (!empty($filter_crop) || !empty($search_query)) ? 'No scans matched your search criteria.' : 'You have not uploaded any crop scans yet.'; ?>
            </p>
            <a href="scan.php" class="btn btn-primary">Run First Scan</a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Leaf Image</th>
                        <th>Crop</th>
                        <th>Diagnosed Disease</th>
                        <th>Confidence</th>
                        <th>Severity</th>
                        <th>Scan Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($history_records as $rec): ?>
                        <tr>
                            <td>
                                <img src="../<?php echo htmlspecialchars($rec['image_path']); ?>" alt="Leaf" style="width: 52px; height: 52px; object-fit: cover; border-radius: 6px; border: 1px solid var(--border);">
                            </td>
                            <td><strong><?php echo htmlspecialchars($rec['crop_type']); ?></strong></td>
                            <td>
                                <div style="font-weight: 600;"><?php echo htmlspecialchars($rec['disease_name']); ?></div>
                                <?php if (!empty($rec['notes'])): ?>
                                    <div style="font-size: 0.8rem; color: var(--text-muted);">
                                        Note: <?php echo htmlspecialchars($rec['notes']); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="font-weight: bold; color: var(--primary);">
                                    <?php echo number_format($rec['confidence'], 1); ?>%
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo strtolower($rec['severity']); ?>">
                                    <?php echo htmlspecialchars($rec['severity']); ?>
                                </span>
                            </td>
                            <td style="font-size: 0.86rem; color: var(--text-muted);">
                                <?php echo date('M d, Y', strtotime($rec['created_at'])); ?><br>
                                <span style="font-size: 0.78rem;"><?php echo date('h:i A', strtotime($rec['created_at'])); ?></span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <a href="report.php?id=<?php echo $rec['prediction_id']; ?>" class="btn btn-sm btn-outline">
                                        Report
                                    </a>
                                    <a href="history.php?delete_id=<?php echo $rec['prediction_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this scan record permanently?');">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
