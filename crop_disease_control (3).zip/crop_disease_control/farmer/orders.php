<?php
// crop_disease_control/farmer/orders.php
// Farmer Order History and Tracking Overview

$depth = 1;
$base_prefix = '../';
$page_title = "My Agro-Chemical Orders";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_login('../login.php');

$current_user = current_user();
$user_id = $current_user['id'];

try {
    $stmt = $pdo->prepare("
        SELECT * FROM `orders` 
        WHERE `user_id` = ? 
        ORDER BY `id` DESC
    ");
    $stmt->execute([$user_id]);
    $my_orders = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card">
    <div class="card-header" style="flex-wrap: wrap; gap: 10px;">
        <div>
            <h1 class="card-title">My Pest & Disease Control Orders</h1>
            <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
                Track orders, check shipment progress, and view purchase receipts.
            </p>
        </div>
        <a href="../shop.php" class="btn btn-primary btn-sm">
            Order More Products
        </a>
    </div>

    <?php if (empty($my_orders)): ?>
        <div style="text-align: center; padding: 40px 20px;">
            <h3 style="color: var(--text-muted); margin-bottom: 8px;">No Orders Placed Yet</h3>
            <p style="color: var(--text-muted); font-size: 0.92rem; margin-bottom: 20px;">
                You haven't ordered any disease control chemicals or equipment yet.
            </p>
            <a href="../shop.php" class="btn btn-primary">Browse Crop Shop</a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Order Ref</th>
                        <th>Date Placed</th>
                        <th>Total Billed</th>
                        <th>Payment Method</th>
                        <th>Payment Status</th>
                        <th>Dispatch Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($my_orders as $ord): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($ord['order_number']); ?></strong><br>
                                <span style="font-size: 0.78rem; color: var(--text-muted);">Track: <?php echo htmlspecialchars($ord['tracking_number']); ?></span>
                            </td>
                            <td style="font-size: 0.86rem; color: var(--text-muted);">
                                <?php echo date('M d, Y', strtotime($ord['created_at'])); ?>
                            </td>
                            <td>
                                <strong>KSh <?php echo number_format($ord['total_amount'], 2); ?></strong>
                            </td>
                            <td><?php echo htmlspecialchars($ord['payment_method']); ?></td>
                            <td>
                                <span class="badge badge-<?php echo $ord['payment_status'] === 'Paid' ? 'healthy' : 'moderate'; ?>">
                                    <?php echo htmlspecialchars($ord['payment_status']); ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-info">
                                    <?php echo htmlspecialchars($ord['order_status']); ?>
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <a href="../track_order.php?order_number=<?php echo urlencode($ord['order_number']); ?>" class="btn btn-sm btn-outline">
                                        Track
                                    </a>
                                    <a href="../order_success.php?id=<?php echo $ord['id']; ?>" class="btn btn-sm btn-outline">
                                        Invoice
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
