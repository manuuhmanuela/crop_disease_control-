<?php
// crop_disease_control/farmer/report.php
// Printable Official Crop Disease Advisory Report

$depth = 1;
$base_prefix = '../';
$page_title = "Diagnostic Advisory Report";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_login('../login.php');

$current_user = current_user();
$prediction_id = (int)($_GET['id'] ?? 0);

if (!$prediction_id) {
    header("Location: history.php");
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            p.id AS prediction_id,
            p.confidence,
            p.notes,
            p.created_at,
            i.image_path,
            i.crop_type,
            i.user_id,
            u.name AS farmer_name,
            u.email AS farmer_email,
            u.phone AS farmer_phone,
            u.county AS farmer_county,
            d.disease_name,
            d.symptoms,
            d.causes,
            d.treatment,
            d.prevention,
            d.severity
        FROM predictions p
        JOIN images i ON p.image_id = i.id
        JOIN users u ON i.user_id = u.id
        JOIN diseases d ON p.disease_id = d.id
        WHERE p.id = ?
    ");
    $stmt->execute([$prediction_id]);
    $report = $stmt->fetch();

    if (!$report) {
        die("Advisory report not found.");
    }

    if ($current_user['role'] !== 'admin' && $report['user_id'] != $current_user['id']) {
        die("Access denied. You do not have permission to view this report.");
    }

} catch (PDOException $e) {
    die("Database query error: " . $e->getMessage());
}

require_once __DIR__ . '/../includes/header.php';
?>

<div style="max-width: 820px; margin: 0 auto;">
    
    <!-- Action Bar (hidden in print) -->
    <div class="no-print" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <a href="history.php" class="btn btn-outline btn-sm">Back to Scan History</a>
        <button onclick="window.print()" class="btn btn-primary btn-sm">
            Print / Save as PDF
        </button>
    </div>

    <!-- Official Report Document -->
    <div class="card" style="padding: 36px; border: 1px solid #cbd5e1; box-shadow: 0 4px 12px rgba(0,0,0,0.05); background:#ffffff;">
        
        <!-- Header -->
        <div style="border-bottom: 2px solid #2e7d32; padding-bottom: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 15px;">
            <div>
                <h2 style="color: #1b5e20; margin: 0; font-size: 1.4rem; font-weight: 800;">
                    AGRISHIELD AI DIAGNOSTIC REPORT
                </h2>
                <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">
                    AI-Based Crop Disease Detection Advisory System &bull; Mount Kenya University Research
                </div>
            </div>
            <div style="text-align: right; font-size: 0.85rem;">
                <div><strong>Report Ref:</strong> #MKU-CROP-<?php echo str_pad($report['prediction_id'], 5, '0', STR_PAD_LEFT); ?></div>
                <div style="color: var(--text-muted);"><strong>Date:</strong> <?php echo date('d M Y, H:i', strtotime($report['created_at'])); ?></div>
            </div>
        </div>

        <!-- Farmer & Crop Overview Table -->
        <div class="grid-2" style="margin-bottom: 24px; background: #f8fafc; border: 1px solid var(--border); border-radius: 6px; padding: 16px;">
            <div>
                <h4 style="color: var(--secondary); margin-bottom: 8px; font-size: 0.9rem; text-transform: uppercase;">Farmer Details:</h4>
                <div style="font-size: 0.9rem; line-height: 1.6;">
                    <div><strong>Name:</strong> <?php echo htmlspecialchars($report['farmer_name']); ?></div>
                    <div><strong>County:</strong> <?php echo htmlspecialchars($report['farmer_county']); ?>, Kenya</div>
                    <div><strong>Contact:</strong> <?php echo htmlspecialchars($report['farmer_phone'] ?: $report['farmer_email']); ?></div>
                </div>
            </div>

            <div>
                <h4 style="color: var(--secondary); margin-bottom: 8px; font-size: 0.9rem; text-transform: uppercase;">Sample Information:</h4>
                <div style="font-size: 0.9rem; line-height: 1.6;">
                    <div><strong>Crop Variety:</strong> <?php echo htmlspecialchars($report['crop_type']); ?></div>
                    <div><strong>Scan Date:</strong> <?php echo date('F j, Y', strtotime($report['created_at'])); ?></div>
                    <?php if (!empty($report['notes'])): ?>
                        <div><strong>Field Notes:</strong> <?php echo htmlspecialchars($report['notes']); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Diagnostic Assessment Summary -->
        <div style="display: flex; gap: 20px; align-items: center; margin-bottom: 24px; flex-wrap: wrap; border-bottom: 1px solid var(--border); padding-bottom: 20px;">
            <div style="width: 140px; text-align: center;">
                <img src="../<?php echo htmlspecialchars($report['image_path']); ?>" alt="Leaf Sample" style="width: 130px; height: 130px; object-fit: cover; border-radius: 6px; border: 1px solid var(--border);">
            </div>
            <div style="flex: 1; min-width: 260px;">
                <span style="font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted); font-weight: 600;">Diagnosed Condition:</span>
                <h3 style="color: #1b5e20; font-size: 1.45rem; margin: 4px 0 8px 0;">
                    <?php echo htmlspecialchars($report['disease_name']); ?>
                </h3>
                <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                    <span class="badge badge-<?php echo strtolower($report['severity']); ?>" style="padding: 6px 14px; font-size: 0.85rem;">
                        Severity: <?php echo htmlspecialchars($report['severity']); ?>
                    </span>
                    <span style="font-size: 0.9rem; font-weight: 600; color: #2e7d32;">
                        AI Prediction Confidence: <?php echo number_format($report['confidence'], 1); ?>%
                    </span>
                </div>
            </div>
        </div>

        <!-- Clinical Details -->
        <div style="margin-bottom: 20px;">
            <h4 style="color: #1b5e20; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 8px;">
                1. Characteristic Symptoms
            </h4>
            <p style="font-size: 0.92rem; color: #334155; line-height: 1.6; margin: 0;">
                <?php echo nl2br(htmlspecialchars($report['symptoms'])); ?>
            </p>
        </div>

        <div style="margin-bottom: 20px;">
            <h4 style="color: #1b5e20; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 8px;">
                2. Pathogen / Causative Factor
            </h4>
            <p style="font-size: 0.92rem; color: #334155; line-height: 1.6; margin: 0;">
                <?php echo nl2br(htmlspecialchars($report['causes'])); ?>
            </p>
        </div>

        <div style="margin-bottom: 20px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 14px;">
            <h4 style="color: #15803d; margin-top: 0; margin-bottom: 6px;">
                3. Prescribed Treatment (Chemical & Organic)
            </h4>
            <p style="font-size: 0.92rem; color: #166534; line-height: 1.6; margin: 0;">
                <?php echo nl2br(htmlspecialchars($report['treatment'])); ?>
            </p>
        </div>

        <div style="margin-bottom: 28px; background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 6px; padding: 14px;">
            <h4 style="color: #0369a1; margin-top: 0; margin-bottom: 6px;">
                4. Field Prevention & Cultural Practices
            </h4>
            <p style="font-size: 0.92rem; color: #0c4a6e; line-height: 1.6; margin: 0;">
                <?php echo nl2br(htmlspecialchars($report['prevention'])); ?>
            </p>
        </div>

        <!-- Signature / Institutional Footer -->
        <div style="border-top: 1px dashed #cbd5e1; padding-top: 16px; display: flex; justify-content: space-between; align-items: flex-end; font-size: 0.8rem; color: var(--text-muted);">
            <div>
                <div><strong>System:</strong> AI-Based Crop Disease Detection System</div>
                <div><strong>Institution:</strong> Mount Kenya University &bull; CIT Research</div>
                <div><strong>Principal Researcher:</strong> Catherine Waringa (CIT/2025/46919)</div>
            </div>
            <div style="text-align: right;">
                <div style="border-bottom: 1px solid #94a3b8; width: 160px; height: 30px; margin-bottom: 4px;"></div>
                <div>Certified Diagnostic Output</div>
            </div>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
