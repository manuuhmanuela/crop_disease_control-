<?php
// crop_disease_control/includes/header.php
// Dedicated Header for Users, Farmers, and Public Website

if (!isset($base_prefix)) {
    $base_prefix = '';
}

require_once __DIR__ . '/auth.php';
$user = current_user();
$flash = get_flash();

// Cart item count calculation
$cart_count = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += (int)($item['quantity'] ?? 0);
    }
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - ' : ''; ?>AgriShield AI Crop Protection</title>
    <link rel="stylesheet" href="<?php echo $base_prefix; ?>assets/css/style.css">
</head>
<body>

<header class="navbar no-print">
    <div class="container nav-container">
        <a href="<?php echo $base_prefix; ?>index.php" class="brand">
            <span>AgriShield AI</span>
        </a>

        <button class="nav-toggle" id="navToggle" aria-label="Toggle navigation">Menu</button>

        <ul class="nav-links" id="navLinks">
            <li><a href="<?php echo $base_prefix; ?>index.php" class="<?php echo $current_page === 'index.php' ? 'active' : ''; ?>">Home</a></li>
            <li><a href="<?php echo $base_prefix; ?>about.php" class="<?php echo $current_page === 'about.php' ? 'active' : ''; ?>">About Us</a></li>
            <li><a href="<?php echo $base_prefix; ?>services.php" class="<?php echo $current_page === 'services.php' ? 'active' : ''; ?>">Services</a></li>
            <li><a href="<?php echo $base_prefix; ?>shop.php" class="<?php echo $current_page === 'shop.php' ? 'active' : ''; ?>">Buy Products</a></li>
            <li><a href="<?php echo $base_prefix; ?>track_order.php" class="<?php echo $current_page === 'track_order.php' ? 'active' : ''; ?>">Track Order</a></li>
            <li>
                <a href="<?php echo $base_prefix; ?>cart.php" class="<?php echo $current_page === 'cart.php' ? 'active' : ''; ?>">
                    Cart
                    <?php if ($cart_count > 0): ?>
                        <span style="background: var(--danger); color: #fff; font-size: 0.72rem; padding: 2px 6px; border-radius: 9999px; margin-left: 2px;">
                            <?php echo $cart_count; ?>
                        </span>
                    <?php endif; ?>
                </a>
            </li>
            <li><a href="<?php echo $base_prefix; ?>contact.php" class="<?php echo $current_page === 'contact.php' ? 'active' : ''; ?>">Contact</a></li>

            <?php if ($user): ?>
                <?php if ($user['role'] === 'admin'): ?>
                    <!-- If Administrator is viewing public site, show a direct button back to Admin Console -->
                    <li>
                        <a href="<?php echo $base_prefix; ?>admin/dashboard.php" class="btn btn-sm btn-primary" style="background:#111827;">
                            Admin Console
                        </a>
                    </li>
                    <li>
                        <span style="font-size: 0.84rem; color: #4b5563; padding: 4px 10px; background: #e5e7eb; border-radius: 9999px;">
                            Admin: <?php echo htmlspecialchars($user['name']); ?>
                        </span>
                    </li>
                    <li><a href="<?php echo $base_prefix; ?>logout.php" class="btn btn-sm btn-outline">Logout</a></li>
                <?php else: ?>
                    <!-- Farmer specific navigation only -->
                    <li><a href="<?php echo $base_prefix; ?>farmer/dashboard.php" class="<?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a></li>
                    <li><a href="<?php echo $base_prefix; ?>farmer/scan.php" class="<?php echo $current_page === 'scan.php' ? 'active' : ''; ?>">AI Diagnose</a></li>
                    <li><a href="<?php echo $base_prefix; ?>farmer/history.php" class="<?php echo $current_page === 'history.php' ? 'active' : ''; ?>">My Scans</a></li>
                    <li><a href="<?php echo $base_prefix; ?>farmer/orders.php" class="<?php echo $current_page === 'orders.php' ? 'active' : ''; ?>">My Orders</a></li>

                    <li>
                        <span style="font-size: 0.84rem; color: #4b5563; padding: 4px 10px; background: #e8f5e9; border-radius: 9999px;">
                            Farmer: <?php echo htmlspecialchars($user['name']); ?>
                        </span>
                    </li>
                    <li><a href="<?php echo $base_prefix; ?>logout.php" class="btn btn-sm btn-outline">Logout</a></li>
                <?php endif; ?>
            <?php else: ?>
                <!-- Guest Visitor Navigation -->
                <li><a href="<?php echo $base_prefix; ?>login.php" class="btn btn-sm btn-outline">Sign In</a></li>
                <li><a href="<?php echo $base_prefix; ?>register.php" class="btn btn-sm btn-primary">Farmer Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</header>

<main style="flex: 1; padding: 24px 0;">
    <div class="container">
        <?php if ($flash): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash['type']); ?>">
                <span><?php echo htmlspecialchars($flash['message']); ?></span>
            </div>
        <?php endif; ?>
