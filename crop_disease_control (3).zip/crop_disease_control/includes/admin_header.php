<?php
// crop_disease_control/includes/admin_header.php
// Dedicated Header for Administrator Portal Only

if (!isset($base_prefix)) {
    $base_prefix = '../';
}

require_once __DIR__ . '/auth.php';
require_admin($base_prefix . 'login.php');

$user = current_user();
$flash = get_flash();

// Current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']);

// Count unread messages and pending orders for badges
$badge_new_messages = 0;
$badge_pending_orders = 0;
try {
    $badge_new_messages = (int)$pdo->query("SELECT COUNT(*) FROM `contact_messages` WHERE `status` = 'New'")->fetchColumn();
    $badge_pending_orders = (int)$pdo->query("SELECT COUNT(*) FROM `orders` WHERE `order_status` = 'Pending'")->fetchColumn();
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - ' : ''; ?>Administrator Console - AgriShield</title>
    <link rel="stylesheet" href="<?php echo $base_prefix; ?>assets/css/style.css">
    <style>
        .admin-navbar {
            background: #111827;
            border-bottom: 2px solid #1f2937;
        }
        .admin-navbar .brand {
            color: #ffffff;
        }
        .admin-navbar .nav-links a {
            color: #d1d5db;
            font-size: 0.88rem;
        }
        .admin-navbar .nav-links a:hover,
        .admin-navbar .nav-links a.active {
            color: #4ade80;
        }
        .admin-badge {
            background: #374151;
            color: #f3f4f6;
            font-size: 0.82rem;
            padding: 4px 10px;
            border-radius: 9999px;
            border: 1px solid #4b5563;
        }
        .counter-pill {
            background: #ef4444;
            color: #ffffff;
            font-size: 0.7rem;
            padding: 1px 6px;
            border-radius: 9999px;
            margin-left: 3px;
        }
    </style>
</head>
<body>

<header class="navbar admin-navbar no-print">
    <div class="container nav-container" style="max-width: 1300px;">
        <a href="dashboard.php" class="brand">
            <span>AgriShield Admin Console</span>
        </a>

        <button class="nav-toggle" id="navToggle" aria-label="Toggle navigation" style="color: #fff; border-color: #4b5563;">Menu</button>

        <ul class="nav-links" id="navLinks" style="gap: 14px;">
            <li><a href="dashboard.php" class="<?php echo $current_page === 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a></li>
            <li><a href="diseases.php" class="<?php echo $current_page === 'diseases.php' ? 'active' : ''; ?>">Diseases</a></li>
            <li><a href="products.php" class="<?php echo $current_page === 'products.php' ? 'active' : ''; ?>">Products</a></li>
            <li>
                <a href="orders.php" class="<?php echo $current_page === 'orders.php' ? 'active' : ''; ?>">
                    Orders
                    <?php if ($badge_pending_orders > 0): ?>
                        <span class="counter-pill"><?php echo $badge_pending_orders; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li><a href="scans.php" class="<?php echo $current_page === 'scans.php' ? 'active' : ''; ?>">Scans</a></li>
            <li><a href="users.php" class="<?php echo $current_page === 'users.php' ? 'active' : ''; ?>">Users</a></li>
            <li>
                <a href="messages.php" class="<?php echo $current_page === 'messages.php' ? 'active' : ''; ?>">
                    Messages
                    <?php if ($badge_new_messages > 0): ?>
                        <span class="counter-pill"><?php echo $badge_new_messages; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li><a href="reports.php" class="<?php echo $current_page === 'reports.php' ? 'active' : ''; ?>">Reports</a></li>
            <li><a href="settings.php" class="<?php echo $current_page === 'settings.php' ? 'active' : ''; ?>">Settings</a></li>

            <li>
                <span class="admin-badge">
                    Administrator: <?php echo htmlspecialchars($user['name']); ?>
                </span>
            </li>
            <li><a href="<?php echo $base_prefix; ?>index.php" target="_blank" style="color: #9ca3af; font-size: 0.82rem;">View Site</a></li>
            <li><a href="<?php echo $base_prefix; ?>logout.php" class="btn btn-sm btn-outline" style="color: #f87171; border-color: #f87171; padding: 4px 10px;">Logout</a></li>
        </ul>
    </div>
</header>

<main style="flex: 1; padding: 24px 0;">
    <div class="container" style="max-width: 1300px;">
        <?php if ($flash): ?>
            <div class="alert alert-<?php echo htmlspecialchars($flash['type']); ?>">
                <span><?php echo htmlspecialchars($flash['message']); ?></span>
            </div>
        <?php endif; ?>
