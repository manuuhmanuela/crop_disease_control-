<?php
// crop_disease_control/includes/footer.php
// Common footer component
if (!isset($base_prefix)) {
    $base_prefix = '';
}
?>
    </div> <!-- /.container -->
</main>

<footer class="no-print">
    <div class="container">
        <div style="margin-bottom: 12px; display: flex; justify-content: center; gap: 20px; flex-wrap: wrap;">
            <a href="<?php echo $base_prefix; ?>index.php" style="color: var(--secondary); text-decoration: none; font-size: 0.9rem;">Home</a>
            <a href="<?php echo $base_prefix; ?>about.php" style="color: var(--secondary); text-decoration: none; font-size: 0.9rem;">About Us</a>
            <a href="<?php echo $base_prefix; ?>services.php" style="color: var(--secondary); text-decoration: none; font-size: 0.9rem;">Our Services</a>
            <a href="<?php echo $base_prefix; ?>shop.php" style="color: var(--secondary); text-decoration: none; font-size: 0.9rem;">Buy Products</a>
            <a href="<?php echo $base_prefix; ?>track_order.php" style="color: var(--secondary); text-decoration: none; font-size: 0.9rem;">Track Order</a>
            <a href="<?php echo $base_prefix; ?>contact.php" style="color: var(--secondary); text-decoration: none; font-size: 0.9rem;">Contact Us</a>
            <a href="<?php echo $base_prefix; ?>login.php" style="color: var(--secondary); text-decoration: none; font-size: 0.9rem;">Sign In</a>
        </div>
       
        <p style="font-size: 0.8rem; color: #9ca3af;">
           Developed By  &bull; Catherine Waringa &bull; All Right Reserved
        </p>
    </div>
</footer>

<script src="<?php echo $base_prefix; ?>assets/js/main.js"></script>
</body>
</html>
