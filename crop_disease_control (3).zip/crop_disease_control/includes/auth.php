<?php
// crop_disease_control/includes/auth.php
// Authentication, session validation, and role-based access control

require_once __DIR__ . '/../config/db.php';

function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function current_user() {
    if (!is_logged_in()) {
        return null;
    }
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? 'User',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'farmer',
        'county' => $_SESSION['user_county'] ?? 'Kenya',
    ];
}

function require_login($redirect_to = null) {
    if (!is_logged_in()) {
        $login_path = $redirect_to ?: 'login.php';
        header("Location: " . $login_path);
        exit;
    }
}

function require_admin($redirect_to = null) {
    require_login($redirect_to);
    if (($_SESSION['user_role'] ?? '') !== 'admin') {
        // Not admin, redirect to farmer dashboard or home
        header("Location: ../farmer/dashboard.php?error=unauthorized");
        exit;
    }
}

// Flash messages helpers
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'info'
        'message' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
?>
