<?php
// crop_disease_control/install.php
// Automatic database setup script for AI-Based Crop Disease Detection & Agro-Control System

$host = 'localhost';
$user = 'root';
$pass = '';
$db_name = 'crop_disease_db';

$status_msg = '';
$is_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['auto'])) {
    try {
        // Connect to MySQL server
        $pdo = new PDO("mysql:host={$host};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);

        // Create Database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `{$db_name}`");

        // Read and execute database.sql
        $sql_file = __DIR__ . '/database.sql';
        if (file_exists($sql_file)) {
            $sql = file_get_contents($sql_file);
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt)) {
                    try {
                        $pdo->exec($stmt);
                    } catch (PDOException $ex) {
                        // Ignore harmless duplicate key errors on repeated runs
                    }
                }
            }
        }

        // Force plain text passwords as requested by user
        $pdo->exec("UPDATE `users` SET `password` = 'admin123' WHERE `email` = 'admin@cropai.ke'");
        $pdo->exec("UPDATE `users` SET `password` = 'farmer123' WHERE `email` = 'catherine@farmer.ke'");

        // Ensure uploads folder exists and write initial demo assets
        $upload_dir = __DIR__ . '/assets/uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $green_png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA8SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBqD7IAAaW4zGIAAAAASUVORK5CYII=');
        file_put_contents($upload_dir . 'sample_maize.png', $green_png);
        file_put_contents($upload_dir . 'sample_tomato.png', $green_png);
        file_put_contents($upload_dir . 'product_default.png', $green_png);
        file_put_contents($upload_dir . 'prod_ridomil.png', $green_png);
        file_put_contents($upload_dir . 'prod_mancozeb.png', $green_png);
        file_put_contents($upload_dir . 'prod_score.png', $green_png);
        file_put_contents($upload_dir . 'prod_actara.png', $green_png);
        file_put_contents($upload_dir . 'prod_copper.png', $green_png);
        file_put_contents($upload_dir . 'prod_neem.png', $green_png);
        file_put_contents($upload_dir . 'prod_sprayer.png', $green_png);
        file_put_contents($upload_dir . 'prod_traps.png', $green_png);

        // Pre-seed sample scan if none exist
        $count_images = $pdo->query("SELECT COUNT(*) FROM `images`")->fetchColumn();
        if ($count_images == 0) {
            $farmer_row = $pdo->query("SELECT id FROM `users` WHERE `email` = 'catherine@farmer.ke' LIMIT 1")->fetch();
            $maize_dis = $pdo->query("SELECT id FROM `diseases` WHERE `disease_name` LIKE '%Maize Lethal Necrosis%' LIMIT 1")->fetch();
            $tomato_dis = $pdo->query("SELECT id FROM `diseases` WHERE `disease_name` LIKE '%Tomato Early Blight%' LIMIT 1")->fetch();

            if ($farmer_row && $maize_dis) {
                $pdo->exec("INSERT INTO `images` (`user_id`, `image_path`, `crop_type`, `uploaded_at`) VALUES ({$farmer_row['id']}, 'assets/uploads/sample_maize.png', 'Maize', NOW() - INTERVAL 2 DAY)");
                $img_id1 = $pdo->lastInsertId();
                $pdo->exec("INSERT INTO `predictions` (`image_id`, `disease_id`, `confidence`, `notes`, `created_at`) VALUES ({$img_id1}, {$maize_dis['id']}, 96.40, 'Yellow mottling and necrotic edges observed on lower foliage in field section 2.', NOW() - INTERVAL 2 DAY)");
            }

            if ($farmer_row && $tomato_dis) {
                $pdo->exec("INSERT INTO `images` (`user_id`, `image_path`, `crop_type`, `uploaded_at`) VALUES ({$farmer_row['id']}, 'assets/uploads/sample_tomato.png', 'Tomato', NOW() - INTERVAL 4 HOUR)");
                $img_id2 = $pdo->lastInsertId();
                $pdo->exec("INSERT INTO `predictions` (`image_id`, `disease_id`, `confidence`, `notes`, `created_at`) VALUES ({$img_id2}, {$tomato_dis['id']}, 93.80, 'Concentric target-like rings noted on greenhouse tomato leaves.', NOW() - INTERVAL 4 HOUR)");
            }
        }

        $is_success = true;
        $status_msg = "Database `{$db_name}` successfully configured with Diseases, Products, Orders, User Accounts (Plaintext Passwords), and Contact tables.";

    } catch (PDOException $e) {
        $status_msg = "Installation error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Setup - AI Crop Disease Detection</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .install-box {
            max-width: 620px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border-top: 4px solid #2e7d32;
        }
        .credential-box {
            background: #f1f8e9;
            border: 1px solid #c8e6c9;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
            font-size: 14px;
        }
    </style>
</head>
<body style="background: #f4f6f8; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #333; line-height: 1.5; padding: 20px;">

<div class="install-box">
    <div style="text-align: center; margin-bottom: 25px;">
        <h2 style="color: #1b5e20; margin: 10px 0 5px 0;">AI Crop Disease Detection System</h2>
        <p style="color: #666; font-size: 14px; margin: 0;">Mount Kenya University Project - Catherine Waringa (CIT/2025/46919)</p>
    </div>

    <?php if ($status_msg): ?>
        <div style="padding: 15px; border-radius: 6px; margin-bottom: 20px; font-weight: 500; <?php echo $is_success ? 'background:#e8f5e9; color:#2e7d32; border:1px solid #c8e6c9;' : 'background:#ffebee; color:#c62828; border:1px solid #ffcdd2;'; ?>">
            <?php echo htmlspecialchars($status_msg); ?>
        </div>
    <?php endif; ?>

    <?php if ($is_success): ?>
        <div class="credential-box">
            <h4 style="margin: 0 0 10px 0; color: #2e7d32;">Default Test Accounts Ready (Plaintext Passwords):</h4>
            <p style="margin: 5px 0;"><strong>Administrator:</strong><br>
               Email: <code>admin@cropai.ke</code><br>
               Password: <code>admin123</code></p>
            <hr style="border: 0; border-top: 1px dashed #a5d6a7; margin: 10px 0;">
            <p style="margin: 5px 0;"><strong>Demo Farmer:</strong><br>
               Email: <code>catherine@farmer.ke</code><br>
               Password: <code>farmer123</code></p>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <a href="login.php" style="flex:1; text-align:center; background:#2e7d32; color:#fff; padding:12px; border-radius:6px; text-decoration:none; font-weight:bold;">Go to Login</a>
            <a href="shop.php" style="flex:1; text-align:center; background:#0284c7; color:#fff; padding:12px; border-radius:6px; text-decoration:none; font-weight:bold;">Agro-Chemical Shop</a>
            <a href="index.php" style="flex:1; text-align:center; background:#fff; color:#2e7d32; border:1px solid #2e7d32; padding:12px; border-radius:6px; text-decoration:none; font-weight:bold;">Home</a>
        </div>
    <?php else: ?>
        <p>This automated installer configures <code>crop_disease_db</code> with complete tables for <strong>Users, Diseases, Scans, Products, Orders, Order Items, Messages, and System Settings</strong>.</p>
        <p style="font-size: 13px; color: #555;">Includes 8+ administrator management modules and complete e-commerce product ordering and order tracking for farmers.</p>

        <form method="POST">
            <button type="submit" style="width: 100%; background: #2e7d32; color: #fff; border: none; padding: 13px; font-size: 16px; font-weight: bold; border-radius: 6px; cursor: pointer; transition: background 0.2s;">
                Install & Seed Database Now
            </button>
        </form>
        <p style="text-align: center; margin-top: 15px; font-size: 13px; color: #777;">
            Ensure MySQL service is running in your XAMPP Control Panel.
        </p>
    <?php endif; ?>
</div>

</body>
</html>
