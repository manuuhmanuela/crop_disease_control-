<?php
// crop_disease_control/cart.php
// Shopping Cart Handler & Display

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle Cart Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $prod_id = (int)($_POST['product_id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));

        if ($prod_id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM `products` WHERE `id` = ?");
            $stmt->execute([$prod_id]);
            $product = $stmt->fetch();

            if ($product) {
                if (isset($_SESSION['cart'][$prod_id])) {
                    $_SESSION['cart'][$prod_id]['quantity'] += $qty;
                } else {
                    $_SESSION['cart'][$prod_id] = [
                        'id' => $product['id'],
                        'name' => $product['name'],
                        'category' => $product['category'],
                        'price' => (float)$product['price'],
                        'quantity' => $qty,
                        'image_path' => $product['image_path']
                    ];
                }
                set_flash('success', "Added {$product['name']} to your cart.");
            }
        }
        header("Location: cart.php");
        exit;
    }

    if ($action === 'update') {
        if (isset($_POST['quantities']) && is_array($_POST['quantities'])) {
            foreach ($_POST['quantities'] as $pid => $new_qty) {
                $pid = (int)$pid;
                $new_qty = (int)$new_qty;
                if ($new_qty <= 0) {
                    unset($_SESSION['cart'][$pid]);
                } elseif (isset($_SESSION['cart'][$pid])) {
                    $_SESSION['cart'][$pid]['quantity'] = $new_qty;
                }
            }
            set_flash('success', "Cart quantities updated.");
        }
        header("Location: cart.php");
        exit;
    }

    if ($action === 'remove') {
        $remove_id = (int)($_POST['product_id'] ?? 0);
        if (isset($_SESSION['cart'][$remove_id])) {
            unset($_SESSION['cart'][$remove_id]);
            set_flash('info', "Item removed from your cart.");
        }
        header("Location: cart.php");
        exit;
    }

    if ($action === 'clear') {
        $_SESSION['cart'] = [];
        set_flash('info', "Your shopping cart has been cleared.");
        header("Location: cart.php");
        exit;
    }
}

// Calculate Totals
$subtotal = 0;
$shipping_fee = count($_SESSION['cart']) > 0 ? 250.00 : 0.00;

foreach ($_SESSION['cart'] as $item) {
    $subtotal += ($item['price'] * $item['quantity']);
}
$grand_total = $subtotal + $shipping_fee;

$page_title = "Shopping Cart";
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 960px; margin: 0 auto;">

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 10px;">
        <div>
            <h1 class="card-title" style="font-size: 1.8rem;">Your Shopping Cart</h1>
            <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">
                Selected crop protection chemicals and equipment.
            </p>
        </div>
        <a href="shop.php" class="btn btn-outline btn-sm">Continue Shopping</a>
    </div>

    <?php if (empty($_SESSION['cart'])): ?>
        <div class="card" style="text-align: center; padding: 48px 20px;">
            <h3 style="color: var(--text-muted); margin-bottom: 8px;">Your Cart is Empty</h3>
            <p style="color: var(--text-muted); font-size: 0.92rem; margin-bottom: 20px;">
                Browse our crop protection catalog to add fungicides, insecticides, or spray equipment.
            </p>
            <a href="shop.php" class="btn btn-primary">Browse Products</a>
        </div>
    <?php else: ?>

        <div class="grid-2" style="grid-template-columns: 2fr 1fr; gap: 24px; align-items: start;">
            
            <!-- Items Table -->
            <div class="card">
                <form method="POST" action="cart.php">
                    <input type="hidden" name="action" value="update">

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th style="width: 100px;">Qty</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($_SESSION['cart'] as $pid => $item): 
                                    $line_total = $item['price'] * $item['quantity'];
                                ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($item['name']); ?></strong><br>
                                            <span class="badge badge-info" style="font-size: 0.72rem;"><?php echo htmlspecialchars($item['category']); ?></span>
                                        </td>
                                        <td>KSh <?php echo number_format($item['price'], 2); ?></td>
                                        <td>
                                            <input type="number" name="quantities[<?php echo $pid; ?>]" value="<?php echo $item['quantity']; ?>" min="1" max="99" class="form-control" style="padding: 4px 8px; width: 70px;">
                                        </td>
                                        <td>
                                            <strong>KSh <?php echo number_format($line_total, 2); ?></strong>
                                        </td>
                                        <td>
                                            <button type="submit" formaction="cart.php" name="action" value="remove" onclick="this.form.product_id.value='<?php echo $pid; ?>';" class="btn btn-sm btn-danger" style="padding: 3px 8px; font-size: 0.8rem;">
                                                Remove
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <input type="hidden" name="product_id" id="remove_product_id" value="0">

                    <div style="display: flex; justify-content: space-between; margin-top: 16px; flex-wrap: wrap; gap: 10px;">
                        <button type="submit" class="btn btn-outline btn-sm">Update Quantities</button>
                        <button type="submit" name="action" value="clear" class="btn btn-sm" style="background:#fee2e2; color:#dc2626;" onclick="return confirmAction('Clear all items from your cart?');">Clear Cart</button>
                    </div>
                </form>
            </div>

            <!-- Order Summary Card -->
            <div class="card" style="border-top: 4px solid var(--primary);">
                <h3 style="font-size: 1.15rem; color: var(--primary-dark); margin-bottom: 16px; border-bottom: 1px solid var(--border); padding-bottom: 8px;">
                    Order Summary
                </h3>

                <div style="display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 0.92rem;">
                    <span>Items Subtotal:</span>
                    <strong>KSh <?php echo number_format($subtotal, 2); ?></strong>
                </div>

                <div style="display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 0.92rem;">
                    <span>Delivery (Countrywide):</span>
                    <strong>KSh <?php echo number_format($shipping_fee, 2); ?></strong>
                </div>

                <hr style="border: 0; border-top: 1px solid var(--border); margin: 12px 0;">

                <div style="display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 1.15rem;">
                    <span style="font-weight: 700;">Grand Total:</span>
                    <span style="font-weight: 800; color: var(--primary-dark);">KSh <?php echo number_format($grand_total, 2); ?></span>
                </div>

                <a href="checkout.php" class="btn btn-primary btn-block" style="padding: 12px; font-size: 1.05rem;">
                    Proceed to Checkout
                </a>

                <div style="margin-top: 14px; font-size: 0.8rem; color: var(--text-muted); line-height: 1.4; text-align: center;">
                    Payments verified via M-Pesa Till or Cash on Delivery upon county arrival.
                </div>
            </div>

        </div>

    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
