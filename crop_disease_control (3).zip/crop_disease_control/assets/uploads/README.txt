# Leaf uploads directory
This directory stores leaf photographs uploaded by farmers for AI analysis.
