<?php
// Generates fallback sample PNG images for demo initial scan records
$upload_dir = __DIR__ . '/assets/uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// 1x1 or simple generated PNGs
// Simple 100x100 solid color PNG data URI decode
$green_png = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAA8SURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOBqD7IAAaW4zGIAAAAASUVORK5CYII=');

file_put_contents($upload_dir . 'sample_maize.png', $green_png);
file_put_contents($upload_dir . 'sample_tomato.png', $green_png);
