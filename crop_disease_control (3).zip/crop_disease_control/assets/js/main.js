// AI-Based Crop Disease Detection System - Client Scripts
document.addEventListener('DOMContentLoaded', () => {
    // Mobile navigation toggle
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('show');
        });
    }

    // Image upload drag-and-drop & preview
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('leafImageInput');
    const previewContainer = document.getElementById('previewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const scanSubmitBtn = document.getElementById('scanSubmitBtn');

    if (dropzone && fileInput) {
        // Click dropzone to trigger input
        dropzone.addEventListener('click', () => {
            fileInput.click();
        });

        // Drag & drop handlers
        ['dragenter', 'dragover'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.add('dragover');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropzone.classList.remove('dragover');
            });
        });

        dropzone.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            if (files.length > 0) {
                fileInput.files = files;
                handleFileSelect(files[0]);
            }
        });

        fileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files.length > 0) {
                handleFileSelect(e.target.files[0]);
            }
        });

        function handleFileSelect(file) {
            // Check file type
            if (!file.type.match('image.*')) {
                alert('Please upload a valid image file (JPG, PNG, or WEBP).');
                return;
            }

            // Display file name
            if (fileNameDisplay) {
                fileNameDisplay.textContent = `${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
            }

            // Preview image
            const reader = new FileReader();
            reader.onload = (e) => {
                if (imagePreview) {
                    imagePreview.src = e.target.result;
                }
                if (previewContainer) {
                    previewContainer.style.display = 'block';
                }
                if (scanSubmitBtn) {
                    scanSubmitBtn.disabled = false;
                }
            };
            reader.readAsDataURL(file);
        }
    }

    // Scan form submission loading state
    const scanForm = document.getElementById('scanForm');
    const scanLoading = document.getElementById('scanLoading');
    if (scanForm && scanLoading) {
        scanForm.addEventListener('submit', () => {
            if (scanSubmitBtn) {
                scanSubmitBtn.style.display = 'none';
            }
            scanLoading.style.display = 'block';
        });
    }
});

// Confirmation helper for deletes
function confirmAction(message) {
    return confirm(message || 'Are you sure you want to proceed with this action?');
}
