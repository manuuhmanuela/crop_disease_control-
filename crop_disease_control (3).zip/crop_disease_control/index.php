<?php
// crop_disease_control/index.php
// Home page and project introduction

$page_title = "Home - AI Crop Disease Detection";
require_once __DIR__ . '/includes/header.php';

// Fetch disease count from DB if available
$disease_count = 14;
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM `diseases`");
    $disease_count = $stmt->fetchColumn();
} catch (Exception $e) {
    // If DB not installed yet, redirect to installer
    header("Location: install.php");
    exit;
}
?>

<div style="background: linear-gradient(135deg, #1b5e20, #2e7d32); color: white; padding: 48px 24px; border-radius: 8px; margin-bottom: 32px; text-align: center;">
    <h1 style="font-size: 2.2rem; font-weight: 800; margin-bottom: 12px;">AI-Based Crop Disease Detection System</h1>
    <p style="font-size: 1.1rem; max-width: 750px; margin: 0 auto 24px auto; opacity: 0.95; line-height: 1.6;">
        Empowering farmers across Kenya with instant, intelligent diagnosis of plant leaf infections. 
        Upload a leaf photo and receive immediate AI disease identification, severity assessment, and treatment guidelines.
    </p>
    
    <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
        <?php if ($user): ?>
            <a href="farmer/scan.php" class="btn btn-primary" style="background:#ffffff; color:#1b5e20; font-weight: bold; padding: 12px 24px; font-size: 1.05rem;">
                Scan Crop Leaf Now
            </a>
            <a href="farmer/dashboard.php" class="btn btn-outline" style="border-color:#ffffff; color:#ffffff; padding: 12px 20px;">
                View Dashboard
            </a>
        <?php else: ?>
            <a href="register.php" class="btn btn-primary" style="background:#ffffff; color:#1b5e20; font-weight: bold; padding: 12px 24px; font-size: 1.05rem;">
                Create Farmer Account
            </a>
            <a href="login.php" class="btn btn-outline" style="border-color:#ffffff; color:#ffffff; padding: 12px 20px;">
                Sign In to System
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Key Highlights -->
<div class="grid-4" style="margin-bottom: 32px;">
    <div class="stat-card">
        <div class="stat-icon" style="font-weight: bold; font-size: 1.1rem;">MZ</div>
        <div>
            <div class="stat-val">Maize</div>
            <div class="stat-label">MLND, Blight & Rust</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="font-weight: bold; font-size: 1.1rem;">TM</div>
        <div>
            <div class="stat-val">Tomatoes</div>
            <div class="stat-label">Early/Late Blight & Curl</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="font-weight: bold; font-size: 1.1rem;">PT</div>
        <div>
            <div class="stat-val">Potatoes</div>
            <div class="stat-label">Late & Early Blight</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="font-weight: bold; font-size: 1.1rem;">BN</div>
        <div>
            <div class="stat-val">Beans</div>
            <div class="stat-label">Rust & Anthracnose</div>
        </div>
    </div>
</div>

<!-- Workflow Section -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">How The System Works</h2>
        <span class="badge badge-info">System Architecture</span>
    </div>
    <div class="grid-4" style="text-align: center;">
        <div style="padding: 16px;">
            <div style="font-size: 1.2rem; font-weight: bold; color: var(--primary); margin-bottom: 8px;">Step 1</div>
            <h4 style="margin-bottom: 6px;">Image Upload</h4>
            <p style="font-size: 0.88rem; color: var(--text-muted);">
                Farmer captures or uploads a photo of the affected plant leaf through smartphone or computer.
            </p>
        </div>
        <div style="padding: 16px;">
            <div style="font-size: 1.2rem; font-weight: bold; color: var(--primary); margin-bottom: 8px;">Step 2</div>
            <h4 style="margin-bottom: 6px;">Feature Extraction</h4>
            <p style="font-size: 0.88rem; color: var(--text-muted);">
                Image algorithms analyze discoloration, lesion edges, chlorosis, and rust pustule patterns.
            </p>
        </div>
        <div style="padding: 16px;">
            <div style="font-size: 1.2rem; font-weight: bold; color: var(--primary); margin-bottom: 8px;">Step 3</div>
            <h4 style="margin-bottom: 6px;">Instant Diagnosis</h4>
            <p style="font-size: 0.88rem; color: var(--text-muted);">
                The system outputs the detected disease name, confidence score, and symptom description.
            </p>
        </div>
        <div style="padding: 16px;">
            <div style="font-size: 1.2rem; font-weight: bold; color: var(--primary); margin-bottom: 8px;">Step 4</div>
            <h4 style="margin-bottom: 6px;">Treatment Advisory</h4>
            <p style="font-size: 0.88rem; color: var(--text-muted);">
                Provides approved chemical fungicides, organic remedies, preventive practices, and printable report.
            </p>
        </div>
    </div>
</div>

<!-- Project Background & Justification -->
<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Problem Addressed</h3>
        </div>
        <p style="font-size: 0.93rem; color: var(--text-main); margin-bottom: 12px;">
            Agriculture contributes approximately one-third of Kenya's GDP and employs over half the population. 
            However, smallholders often suffer heavy yield losses due to delays in accessing agricultural extension officers.
        </p>
        <p style="font-size: 0.93rem; color: var(--text-muted);">
            Inaccurate manual diagnosis frequently leads to applying incorrect pesticides, inflating production costs while polluting the ecosystem. 
            This AI platform delivers immediate, accessible diagnostics at zero consultation fee.
        </p>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">System Scope & Capacity</h3>
        </div>
        <ul style="padding-left: 20px; font-size: 0.93rem; color: var(--text-main); line-height: 1.8;">
            <li>Current knowledgebase contains <strong><?php echo (int)$disease_count; ?></strong> disease profiles.</li>
            <li>Covers high-priority staple and cash crops: Maize, Tomatoes, Potatoes, and Beans.</li>
            <li>Stores historical diagnosis logs for every farmer to track field improvement.</li>
            <li>Centralized administrative oversight for agricultural officers and system managers.</li>
        </ul>
        <div style="margin-top: 14px;">
            <a href="services.php" class="btn btn-sm btn-outline">Explore All Services</a>
            <a href="about.php" class="btn btn-sm btn-outline" style="margin-left: 6px;">Read Full Proposal</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
