<?php
// crop_disease_control/checkout.php
// Complete Payments and Place Order

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

// Cart must not be empty
if (empty($_SESSION['cart'])) {
    header("Location: shop.php");
    exit;
}

$user = current_user();

// Calculate Totals
$subtotal = 0;
$shipping_fee = 250.00;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += ($item['price'] * $item['quantity']);
}
$grand_total = $subtotal + $shipping_fee;

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $shipping_name = sanitize($_POST['shipping_name'] ?? '');
    $shipping_phone = sanitize($_POST['shipping_phone'] ?? '');
    $shipping_county = sanitize($_POST['shipping_county'] ?? 'Nakuru');
    $shipping_address = sanitize($_POST['shipping_address'] ?? '');
    $payment_method = sanitize($_POST['payment_method'] ?? 'M-Pesa');
    $mpesa_code = sanitize($_POST['mpesa_code'] ?? '');
    $order_notes = sanitize($_POST['notes'] ?? '');

    if (empty($shipping_name) || empty($shipping_phone) || empty($shipping_address)) {
        $error = 'Please fill in all required shipping contact fields.';
    } else {
        try {
            // Find or associate user ID
            $user_id = $user ? $user['id'] : 0;

            // If guest user without account, find or create customer record
            if ($user_id === 0) {
                $guest_email = sanitize($_POST['shipping_email'] ?? 'guest@farmer.ke');
                $chk_u = $pdo->prepare("SELECT id FROM `users` WHERE `email` = ?");
                $chk_u->execute([$guest_email]);
                $found_u = $chk_u->fetch();

                if ($found_u) {
                    $user_id = $found_u['id'];
                } else {
                    $ins_u = $pdo->prepare("INSERT INTO `users` (`name`, `email`, `password`, `phone`, `county`, `role`) VALUES (?, ?, 'farmer123', ?, ?, 'farmer')");
                    $ins_u->execute([$shipping_name, $guest_email, $shipping_phone, $shipping_county]);
                    $user_id = $pdo->lastInsertId();
                }
            }

            // Generate Order & Tracking Numbers
            $order_number = 'ORD-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $tracking_number = 'TRK-KE-' . rand(10000, 99999);

            // Determine Payment Status
            $payment_status = 'Pending';
            if ($payment_method === 'M-Pesa') {
                $payment_status = !empty($mpesa_code) ? 'Paid' : 'Pending';
            } elseif ($payment_method === 'Bank Card') {
                $payment_status = 'Paid';
            }

            $order_status = 'Pending';

            // Insert Order
            $stmt = $pdo->prepare("
                INSERT INTO `orders` (
                    `order_number`, `user_id`, `total_amount`, `shipping_fee`, 
                    `payment_method`, `payment_status`, `order_status`, 
                    `shipping_name`, `shipping_phone`, `shipping_county`, 
                    `shipping_address`, `tracking_number`, `notes`
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $full_notes = $order_notes;
            if (!empty($mpesa_code)) {
                $full_notes .= " [M-Pesa Ref: {$mpesa_code}]";
            }
            $stmt->execute([
                $order_number, $user_id, $grand_total, $shipping_fee,
                $payment_method, $payment_status, $order_status,
                $shipping_name, $shipping_phone, $shipping_county,
                $shipping_address, $tracking_number, $full_notes
            ]);
            $order_id = $pdo->lastInsertId();

            // Insert Order Items and reduce stock
            $stmt_item = $pdo->prepare("
                INSERT INTO `order_items` (`order_id`, `product_id`, `product_name`, `price`, `quantity`, `subtotal`)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt_stock = $pdo->prepare("UPDATE `products` SET `stock_quantity` = GREATEST(0, `stock_quantity` - ?) WHERE `id` = ?");

            foreach ($_SESSION['cart'] as $pid => $item) {
                $item_subtotal = $item['price'] * $item['quantity'];
                $stmt_item->execute([$order_id, $pid, $item['name'], $item['price'], $item['quantity'], $item_subtotal]);
                $stmt_stock->execute([$item['quantity'], $pid]);
            }

            // Clear Cart
            $_SESSION['cart'] = [];
            set_flash('success', "Order {$order_number} placed successfully.");

            header("Location: order_success.php?id={$order_id}");
            exit;

        } catch (PDOException $e) {
            $error = 'Failed to process order: ' . $e->getMessage();
        }
    }
}

$page_title = "Checkout & Payment";
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 960px; margin: 0 auto;">

    <div style="margin-bottom: 24px;">
        <h1 class="card-title" style="font-size: 1.8rem; margin-bottom: 4px;">Complete Your Order & Payment</h1>
        <p style="font-size: 0.9rem; color: var(--text-muted); margin: 0;">
            Provide shipping location and select payment options for countrywide agro-delivery.
        </p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="checkout.php">
        <div class="grid-2" style="grid-template-columns: 1.8fr 1.2fr; gap: 24px; align-items: start;">
            
            <!-- Shipping & Payment Form -->
            <div>
                <!-- Shipping Details -->
                <div class="card" style="margin-bottom: 20px;">
                    <div class="card-header">
                        <h2 class="card-title" style="font-size: 1.2rem;">1. Delivery Destination</h2>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="shipping_name">Full Name *</label>
                        <input type="text" name="shipping_name" id="shipping_name" class="form-control" value="<?php echo htmlspecialchars($user ? $user['name'] : ''); ?>" required>
                    </div>

                    <div class="grid-2">
                        <div class="form-group">
                            <label class="form-label" for="shipping_phone">Contact Phone Number *</label>
                            <input type="tel" name="shipping_phone" id="shipping_phone" class="form-control" placeholder="+254 712 345 678" value="<?php echo htmlspecialchars($user ? ($_SESSION['user_phone'] ?? '') : ''); ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="shipping_county">County *</label>
                            <select name="shipping_county" id="shipping_county" class="form-control" required>
                                <?php
                                $counties = ['Nakuru', 'Kiambu', 'Uasin Gishu', 'Trans Nzoia', 'Machakos', 'Meru', 'Nyeri', 'Bungoma', 'Kakamega', 'Murang\'a', 'Kisii', 'Other'];
                                $user_county = $user ? $user['county'] : 'Nakuru';
                                foreach ($counties as $c) {
                                    $sel = ($user_county === $c) ? 'selected' : '';
                                    echo "<option value=\"$c\" $sel>$c</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <?php if (!$user): ?>
                        <div class="form-group">
                            <label class="form-label" for="shipping_email">Email Address (for order confirmation)</label>
                            <input type="email" name="shipping_email" id="shipping_email" class="form-control" placeholder="farmer@example.com">
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label class="form-label" for="shipping_address">Delivery Address / Local Town / Landmark *</label>
                        <input type="text" name="shipping_address" id="shipping_address" class="form-control" placeholder="e.g. Njoro Town, Near Main Stage or Block 4 Farm" required>
                    </div>

                    <div class="form-group" style="margin-bottom: 0;">
                        <label class="form-label" for="notes">Delivery Instructions (Optional)</label>
                        <textarea name="notes" id="notes" class="form-control" rows="2" placeholder="e.g. Call upon arrival at local dispatch center"></textarea>
                    </div>
                </div>

                <!-- Payment Selection -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title" style="font-size: 1.2rem;">2. Payment Method</h2>
                    </div>

                    <div class="form-group">
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; border: 1px solid var(--border); padding: 12px; border-radius: 6px; background: #f8fafc;">
                                <input type="radio" name="payment_method" value="M-Pesa" checked onclick="document.getElementById('mpesaBox').style.display='block';">
                                <div>
                                    <strong>M-Pesa Express / Buy Goods</strong>
                                    <div style="font-size: 0.8rem; color: var(--text-muted);">Pay via Till Number 5829104 (AgriShield Kenya)</div>
                                </div>
                            </label>

                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; border: 1px solid var(--border); padding: 12px; border-radius: 6px; background: #f8fafc;">
                                <input type="radio" name="payment_method" value="Cash on Delivery" onclick="document.getElementById('mpesaBox').style.display='none';">
                                <div>
                                    <strong>Cash on Delivery</strong>
                                    <div style="font-size: 0.8rem; color: var(--text-muted);">Pay cash to courier driver or pickup agent upon inspection</div>
                                </div>
                            </label>

                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; border: 1px solid var(--border); padding: 12px; border-radius: 6px; background: #f8fafc;">
                                <input type="radio" name="payment_method" value="Bank Card" onclick="document.getElementById('mpesaBox').style.display='none';">
                                <div>
                                    <strong>Credit / Debit Card (Visa / Mastercard)</strong>
                                    <div style="font-size: 0.8rem; color: var(--text-muted);">Instant secure card clearance</div>
                                </div>
                            </label>
                        </div>
                    </div>

                    <!-- M-Pesa Instruction Details -->
                    <div id="mpesaBox" style="background: #f1f8e9; border: 1px solid #c8e6c9; border-radius: 6px; padding: 14px; margin-top: 10px;">
                        <h4 style="color: #2e7d32; margin-bottom: 6px; font-size: 0.95rem;">M-Pesa Payment Procedure:</h4>
                        <ol style="margin-left: 20px; font-size: 0.85rem; color: #374151; line-height: 1.6;">
                            <li>Go to M-Pesa on your phone</li>
                            <li>Select <strong>Lipa na M-Pesa</strong> &gt; <strong>Buy Goods and Services</strong></li>
                            <li>Enter Till Number: <strong>5829104</strong></li>
                            <li>Enter Exact Amount: <strong>KSh <?php echo number_format($grand_total, 2); ?></strong></li>
                            <li>Enter your PIN and complete</li>
                        </ol>
                        <div style="margin-top: 10px;">
                            <label class="form-label" for="mpesa_code" style="font-size: 0.85rem;">M-Pesa Transaction Code (Optional for instant clearance)</label>
                            <input type="text" name="mpesa_code" id="mpesa_code" class="form-control" placeholder="e.g. QKH78291XK" style="text-transform: uppercase;">
                        </div>
                    </div>

                </div>
            </div>

            <!-- Order Review Card -->
            <div class="card" style="border-top: 4px solid var(--primary); position: sticky; top: 90px;">
                <h3 style="font-size: 1.15rem; color: var(--primary-dark); margin-bottom: 14px; border-bottom: 1px solid var(--border); padding-bottom: 8px;">
                    Order Review (<?php echo count($_SESSION['cart']); ?> Items)
                </h3>

                <div style="max-height: 220px; overflow-y: auto; margin-bottom: 16px;">
                    <?php foreach ($_SESSION['cart'] as $item): ?>
                        <div style="display: flex; justify-content: space-between; font-size: 0.88rem; margin-bottom: 8px; border-bottom: 1px dashed #e2e8f0; padding-bottom: 6px;">
                            <div>
                                <strong><?php echo htmlspecialchars($item['name']); ?></strong><br>
                                <span style="font-size: 0.78rem; color: var(--text-muted);"><?php echo $item['quantity']; ?> &times; KSh <?php echo number_format($item['price'], 2); ?></span>
                            </div>
                            <div>
                                <strong>KSh <?php echo number_format($item['price'] * $item['quantity'], 2); ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div style="display: flex; justify-content: space-between; font-size: 0.9rem; margin-bottom: 8px;">
                    <span>Subtotal:</span>
                    <strong>KSh <?php echo number_format($subtotal, 2); ?></strong>
                </div>

                <div style="display: flex; justify-content: space-between; font-size: 0.9rem; margin-bottom: 12px;">
                    <span>Shipping Fee:</span>
                    <strong>KSh <?php echo number_format($shipping_fee, 2); ?></strong>
                </div>

                <hr style="border: 0; border-top: 1px solid var(--border); margin: 10px 0;">

                <div style="display: flex; justify-content: space-between; font-size: 1.2rem; margin-bottom: 20px;">
                    <span style="font-weight: 700;">Total Payable:</span>
                    <span style="font-weight: 800; color: var(--primary-dark);">KSh <?php echo number_format($grand_total, 2); ?></span>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="padding: 13px; font-size: 1.05rem;">
                    Confirm & Complete Order
                </button>

                <div style="margin-top: 12px; text-align: center;">
                    <a href="cart.php" style="color: var(--secondary); font-size: 0.85rem; text-decoration: none;">← Modify Cart</a>
                </div>
            </div>

        </div>
    </form>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
