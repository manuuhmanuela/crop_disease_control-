<?php
// crop_disease_control/shop.php
// Agro-Chemical & Disease Control Product Catalog

$page_title = "Buy Crop Disease & Pest Control Products";
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/header.php';

// Fetch filters
$category_filter = sanitize($_GET['category'] ?? '');
$crop_filter = sanitize($_GET['crop'] ?? '');
$search_q = sanitize($_GET['q'] ?? '');

$sql = "SELECT * FROM `products` WHERE 1=1";
$params = [];

if (!empty($category_filter)) {
    $sql .= " AND `category` = ?";
    $params[] = $category_filter;
}
if (!empty($crop_filter)) {
    $sql .= " AND (`target_crop` LIKE ? OR `target_crop` = 'All Crops')";
    $params[] = "%{$crop_filter}%";
}
if (!empty($search_q)) {
    $sql .= " AND (`name` LIKE ? OR `target_disease` LIKE ? OR `description` LIKE ?)";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
}

$sql .= " ORDER BY `id` ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>

<div style="background: linear-gradient(135deg, #1b5e20, #2e7d32); color: white; padding: 36px 20px; border-radius: 8px; margin-bottom: 24px;">
    <div style="max-width: 800px; margin: 0 auto; text-align: center;">
        <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 8px;">Pest & Disease Control Products</h1>
        <p style="font-size: 1rem; opacity: 0.95; margin: 0;">
            Certified fungicides, insecticides, biopesticides, and application tools to control crop diseases across Kenya.
        </p>
    </div>
</div>

<!-- Search & Filter Bar -->
<div class="card" style="margin-bottom: 24px; padding: 18px;">
    <form method="GET" action="shop.php" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
        <div style="flex: 1; min-width: 220px;">
            <input type="text" name="q" class="form-control" placeholder="Search product name, disease (e.g. Blight, Rust, MLND)..." value="<?php echo htmlspecialchars($search_q); ?>">
        </div>

        <div style="min-width: 150px;">
            <select name="category" class="form-control" onchange="this.form.submit()">
                <option value="">All Categories</option>
                <option value="Fungicide" <?php echo $category_filter === 'Fungicide' ? 'selected' : ''; ?>>Fungicides</option>
                <option value="Insecticide" <?php echo $category_filter === 'Insecticide' ? 'selected' : ''; ?>>Insecticides</option>
                <option value="Bio-Pesticide" <?php echo $category_filter === 'Bio-Pesticide' ? 'selected' : ''; ?>>Bio-Pesticides</option>
                <option value="Equipment" <?php echo $category_filter === 'Equipment' ? 'selected' : ''; ?>>Equipment</option>
                <option value="Fertilizer" <?php echo $category_filter === 'Fertilizer' ? 'selected' : ''; ?>>Fertilizers</option>
            </select>
        </div>

        <div style="min-width: 140px;">
            <select name="crop" class="form-control" onchange="this.form.submit()">
                <option value="">All Target Crops</option>
                <option value="Maize" <?php echo $crop_filter === 'Maize' ? 'selected' : ''; ?>>Maize</option>
                <option value="Tomato" <?php echo $crop_filter === 'Tomato' ? 'selected' : ''; ?>>Tomato</option>
                <option value="Potato" <?php echo $crop_filter === 'Potato' ? 'selected' : ''; ?>>Potato</option>
                <option value="Beans" <?php echo $crop_filter === 'Beans' ? 'selected' : ''; ?>>Beans</option>
            </select>
        </div>

        <div>
            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
            <?php if (!empty($category_filter) || !empty($crop_filter) || !empty($search_q)): ?>
                <a href="shop.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151; margin-left: 4px;">Reset</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- Products Grid -->
<?php if (empty($products)): ?>
    <div class="card" style="text-align: center; padding: 40px 20px;">
        <h3 style="color: var(--text-muted); margin-bottom: 8px;">No Products Found</h3>
        <p style="color: var(--text-muted); font-size: 0.92rem; margin-bottom: 16px;">
            No items matched your current filter selection.
        </p>
        <a href="shop.php" class="btn btn-primary btn-sm">View All Products</a>
    </div>
<?php else: ?>
    <div class="grid-3" style="gap: 20px;">
        <?php foreach ($products as $prod): ?>
            <div class="card" style="display: flex; flex-direction: column; padding: 20px; border-radius: 8px; justify-content: space-between;">
                <div>
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                        <span class="badge badge-info"><?php echo htmlspecialchars($prod['category']); ?></span>
                        <span style="font-size: 0.8rem; color: <?php echo $prod['stock_quantity'] > 0 ? 'var(--success)' : 'var(--danger)'; ?>; font-weight: 600;">
                            <?php echo $prod['stock_quantity'] > 0 ? "In Stock ({$prod['stock_quantity']})" : "Out of Stock"; ?>
                        </span>
                    </div>

                    <h3 style="font-size: 1.15rem; color: var(--primary-dark); margin-bottom: 6px; line-height: 1.3;">
                        <?php echo htmlspecialchars($prod['name']); ?>
                    </h3>

                    <div style="font-size: 0.84rem; color: var(--text-muted); margin-bottom: 10px;">
                        <strong>Target Crops:</strong> <?php echo htmlspecialchars($prod['target_crop']); ?><br>
                        <strong>Controls:</strong> <?php echo htmlspecialchars($prod['target_disease']); ?>
                    </div>

                    <p style="font-size: 0.88rem; color: #4b5563; line-height: 1.5; margin-bottom: 12px;">
                        <?php echo htmlspecialchars(mb_strimwidth($prod['description'], 0, 120, '...')); ?>
                    </p>

                    <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 6px; padding: 8px 10px; font-size: 0.8rem; margin-bottom: 16px;">
                        <strong>Application / Dosage:</strong><br>
                        <?php echo htmlspecialchars($prod['dosage']); ?>
                    </div>
                </div>

                <div style="border-top: 1px solid var(--border); padding-top: 14px; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span style="font-size: 0.78rem; color: var(--text-muted); display: block;">Price:</span>
                        <span style="font-size: 1.25rem; font-weight: 800; color: var(--primary-dark);">
                            KSh <?php echo number_format($prod['price'], 2); ?>
                        </span>
                    </div>

                    <form method="POST" action="cart.php">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
                        <input type="hidden" name="quantity" value="1">
                        <button type="submit" class="btn btn-sm btn-primary" <?php echo $prod['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>
                            <?php echo $prod['stock_quantity'] > 0 ? 'Add to Cart' : 'Sold Out'; ?>
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
