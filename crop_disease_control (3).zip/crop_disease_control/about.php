<?php
// crop_disease_control/about.php
// About Us - Project Background, Objectives, and Institutional Profile

$page_title = "About Us";
require_once __DIR__ . '/includes/header.php';
?>

<div style="background: linear-gradient(135deg, #1b5e20, #2e7d32); color: white; padding: 40px 24px; border-radius: 8px; margin-bottom: 28px; text-align: center;">
    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 10px;">About AgriShield AI</h1>
    <p style="font-size: 1.05rem; max-width: 720px; margin: 0 auto; opacity: 0.95; line-height: 1.6;">
        Design and Development of an AI-Based Crop Disease Detection System for Kenyan Smallholder Agriculture.
    </p>
</div>

<!-- Institutional Profile -->
<div class="card">
    <div class="card-header">
        <h2 class="card-title">Academic & Project Background</h2>
        <span class="badge badge-info">Mount Kenya University</span>
    </div>
    <div class="grid-2" style="align-items: center;">
        <div>
            <p style="font-size: 0.95rem; line-height: 1.7; margin-bottom: 12px;">
                This project was formulated and developed under the <strong>School of Computing and Information Technology</strong> at <strong>Mount Kenya University</strong> in partial fulfilment of the requirements for the degree in Information Technology.
            </p>
            <div style="background: #f8fafc; border: 1px solid var(--border); border-radius: 6px; padding: 16px; font-size: 0.9rem; line-height: 1.6;">
                <div><strong>Lead Researcher:</strong> Catherine Waringa</div>
                <div><strong>Registration Number:</strong> CIT/2025/46919</div>
                <div><strong>Target Sectors:</strong> Smallholder Farmers, Agricultural Extension, Food Security</div>
                <div><strong>Methodology:</strong> Agile Software Development with Computer Vision & Deep Learning</div>
            </div>
        </div>
        <div style="background: #f1f8e9; border: 1px solid #c8e6c9; border-radius: 8px; padding: 20px;">
            <h4 style="color: #1b5e20; margin-bottom: 8px;">Institutional Mandate</h4>
            <p style="font-size: 0.9rem; color: #374151; margin: 0; line-height: 1.6;">
                Agriculture remains the backbone of Kenya's economy, contributing approximately one-third of the Gross Domestic Product and employing more than half of the national labor force. 
                By marrying machine learning techniques with accessible web platforms, this project bridges the critical diagnostic gap between rural farmers and scarce agricultural experts.
            </p>
        </div>
    </div>
</div>

<!-- Problem Statement & Justification -->
<div class="grid-2">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Problem Statement</h3>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-main); margin-bottom: 12px; line-height: 1.6;">
            Crop diseases continue to cause catastrophic economic losses to farmers due to delayed detection and inaccurate manual diagnosis. 
            Many small-scale farmers cannot afford private consultants or access government extension officers in remote rural zones.
        </p>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6;">
            Consequently, farmers frequently misidentify symptoms, applying inappropriate chemical fungicides or pesticides. 
            This raises production overheads, harms soil biology, and accelerates yield collapse. An automated, real-time AI diagnostic tool addresses this vulnerability directly.
        </p>
    </div>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Project Objectives</h3>
        </div>
        <div style="font-size: 0.92rem; line-height: 1.7;">
            <p style="font-weight: 600; color: var(--primary-dark); margin-bottom: 6px;">General Objective:</p>
            <p style="margin-bottom: 10px;">To design and develop an AI-Based Crop Disease Detection System that uses artificial intelligence to identify plant infections and prescribe actionable treatments.</p>
            
            <p style="font-weight: 600; color: var(--primary-dark); margin-bottom: 6px;">Specific Objectives:</p>
            <ul style="padding-left: 20px; color: var(--text-muted);">
                <li>Develop a user-friendly, responsive web platform accessible on low-bandwidth connections.</li>
                <li>Implement an AI model trained to recognize leaf features across Maize, Tomatoes, Potatoes, and Beans.</li>
                <li>Provide automated chemical and cultural treatment recommendations.</li>
                <li>Maintain a verifiable disease knowledgebase and historical diagnosis audit trail.</li>
            </ul>
        </div>
    </div>
</div>

<!-- Scope & Target Crops -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Supported Agricultural Scope</h3>
    </div>
    <p style="font-size: 0.92rem; color: var(--text-muted); margin-bottom: 18px;">
        The system focuses on high-impact staple and commercial crops vital to Kenyan household incomes:
    </p>
    <div class="grid-4" style="text-align: center;">
        <div style="border: 1px solid var(--border); border-radius: 6px; padding: 16px; background: #fff;">
            <h4 style="color: var(--primary-dark); margin-bottom: 6px;">Maize</h4>
            <p style="font-size: 0.82rem; color: var(--text-muted); margin: 0;">
                Maize Lethal Necrosis (MLND), Common Rust, Northern Corn Leaf Blight.
            </p>
        </div>
        <div style="border: 1px solid var(--border); border-radius: 6px; padding: 16px; background: #fff;">
            <h4 style="color: var(--primary-dark); margin-bottom: 6px;">Tomatoes</h4>
            <p style="font-size: 0.82rem; color: var(--text-muted); margin: 0;">
                Early Blight, Late Blight, Tomato Yellow Leaf Curl Virus (TYLCV).
            </p>
        </div>
        <div style="border: 1px solid var(--border); border-radius: 6px; padding: 16px; background: #fff;">
            <h4 style="color: var(--primary-dark); margin-bottom: 6px;">Potatoes</h4>
            <p style="font-size: 0.82rem; color: var(--text-muted); margin: 0;">
                Late Blight (Phytophthora infestans), Early Blight (Alternaria solani).
            </p>
        </div>
        <div style="border: 1px solid var(--border); border-radius: 6px; padding: 16px; background: #fff;">
            <h4 style="color: var(--primary-dark); margin-bottom: 6px;">Beans</h4>
            <p style="font-size: 0.82rem; color: var(--text-muted); margin: 0;">
                Bean Rust (Uromyces appendiculatus), Bean Anthracnose.
            </p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
