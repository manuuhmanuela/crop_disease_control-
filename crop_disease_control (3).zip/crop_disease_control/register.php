<?php
// crop_disease_control/register.php
// User Registration for Farmers (Plaintext passwords enabled)

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

if (is_logged_in()) {
    header("Location: farmer/dashboard.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $county = sanitize($_POST['county'] ?? 'Nakuru');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (empty($name) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields (Name, Email, and Password).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please provide a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $password_confirm) {
        $error = 'Passwords do not match.';
    } else {
        try {
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'An account with this email address already exists. Please log in.';
            } else {
                // Store password in plain text as requested
                $insert = $pdo->prepare("INSERT INTO users (name, email, password, phone, county, role) VALUES (?, ?, ?, ?, ?, 'farmer')");
                $insert->execute([$name, $email, $password, $phone, $county]);

                // Auto login user
                $user_id = $pdo->lastInsertId();
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_role'] = 'farmer';
                $_SESSION['user_county'] = $county;

                set_flash('success', "Welcome to AgriShield AI, {$name}. Your farmer account has been created.");
                header("Location: farmer/dashboard.php");
                exit;
            }
        } catch (PDOException $e) {
            $error = 'Registration failed: ' . $e->getMessage();
        }
    }
}

$page_title = "Farmer Registration";
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 520px; margin: 20px auto;">
    <div class="card">
        <div class="card-header" style="text-align: center; display: block;">
            <h2 class="card-title" style="margin-bottom: 4px;">Farmer Account Registration</h2>
            <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
                Join the AI Crop Disease Detection Platform
            </p>
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="register.php">
            <div class="form-group">
                <label class="form-label" for="name">Full Name *</label>
                <input type="text" id="name" name="name" class="form-control" placeholder="e.g. Catherine Waringa" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label" for="email">Email Address *</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="farmer@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
            </div>

            <div class="grid-2" style="gap: 12px;">
                <div class="form-group">
                    <label class="form-label" for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="form-control" placeholder="+254 712 345 678" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="county">County / Region</label>
                    <select id="county" name="county" class="form-control">
                        <?php
                        $counties = ['Nakuru', 'Kiambu', 'Uasin Gishu', 'Trans Nzoia', 'Machakos', 'Meru', 'Nyeri', 'Bungoma', 'Kakamega', 'Murang\'a', 'Kisii', 'Other'];
                        foreach ($counties as $c) {
                            $selected = (isset($_POST['county']) && $_POST['county'] === $c) ? 'selected' : '';
                            echo "<option value=\"$c\" $selected>$c</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password (Minimum 6 characters) *</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Create password" required>
            </div>

            <div class="form-group">
                <label class="form-label" for="password_confirm">Confirm Password *</label>
                <input type="password" id="password_confirm" name="password_confirm" class="form-control" placeholder="Re-enter password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block" style="padding: 12px; font-size: 1rem; margin-top: 10px;">
                Create Account
            </button>
        </form>

        <div style="text-align: center; margin-top: 20px; font-size: 0.9rem; color: var(--text-muted); border-top: 1px solid var(--border); padding-top: 16px;">
            Already registered? <a href="login.php" style="color: var(--primary); font-weight: 600;">Sign in here</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
