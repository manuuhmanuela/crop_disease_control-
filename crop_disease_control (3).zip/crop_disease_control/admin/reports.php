<?php
// crop_disease_control/admin/reports.php
// Administrator Agricultural Reports & Outbreak Analytics

$depth = 1;
$base_prefix = '../';
$page_title = "Agricultural Analytics & Reports";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

// 1. Disease Frequency & Severity Report
$disease_stats = [];
try {
    $stmt = $pdo->query("
        SELECT 
            d.crop_name,
            d.disease_name,
            d.severity,
            COUNT(p.id) as detection_count,
            AVG(p.confidence) as avg_confidence
        FROM diseases d
        LEFT JOIN predictions p ON d.id = p.disease_id
        GROUP BY d.id
        ORDER BY detection_count DESC, d.crop_name ASC
    ");
    $disease_stats = $stmt->fetchAll();
} catch (PDOException $e) {}

// 2. County Disease Distribution
$county_stats = [];
try {
    $stmt = $pdo->query("
        SELECT 
            COALESCE(u.county, 'Unspecified') as county_name,
            COUNT(p.id) as total_scans,
            SUM(CASE WHEN d.severity = 'Severe' THEN 1 ELSE 0 END) as severe_outbreaks
        FROM predictions p
        JOIN images i ON p.image_id = i.id
        JOIN users u ON i.user_id = u.id
        JOIN diseases d ON p.disease_id = d.id
        GROUP BY u.county
        ORDER BY total_scans DESC
    ");
    $county_stats = $stmt->fetchAll();
} catch (PDOException $e) {}

// 3. E-Commerce Sales Revenue Summary
$total_revenue = 0;
$total_units_sold = 0;
$top_products = [];
try {
    $stmt_rev = $pdo->query("SELECT SUM(total_amount) FROM `orders` WHERE `payment_status` = 'Paid'");
    $total_revenue = (float)$stmt_rev->fetchColumn() ?: 0.00;

    $stmt_units = $pdo->query("SELECT SUM(quantity) FROM `order_items`");
    $total_units_sold = (int)$stmt_units->fetchColumn() ?: 0;

    $stmt_top = $pdo->query("
        SELECT product_name, SUM(quantity) as units_sold, SUM(subtotal) as total_sales
        FROM `order_items`
        GROUP BY product_name
        ORDER BY units_sold DESC
        LIMIT 5
    ");
    $top_products = $stmt_top->fetchAll();
} catch (PDOException $e) {}

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 10px;">
    <div>
        <h1 class="card-title" style="font-size: 1.6rem;">Agricultural Disease Analytics & Sales Reports</h1>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
            Epidemiological disease monitoring across Kenyan agricultural zones & agro-input distribution metrics.
        </p>
    </div>
    <button onclick="window.print()" class="btn btn-primary btn-sm no-print">
        Print Analytics Report
    </button>
</div>

<!-- KPI Summary -->
<div class="grid-3" style="margin-bottom: 24px;">
    <div class="stat-card">
        <div class="stat-icon" style="background:#fee2e2; color:#dc2626; font-size: 0.85rem; font-weight:bold;">OUT</div>
        <div>
            <div class="stat-val" style="color: #dc2626;">
                <?php 
                $severe_total = 0;
                foreach ($county_stats as $cs) { $severe_total += (int)$cs['severe_outbreaks']; }
                echo $severe_total;
                ?>
            </div>
            <div class="stat-label">Severe Outbreaks Identified</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7; color:#15803d; font-size: 0.85rem; font-weight:bold;">KSH</div>
        <div>
            <div class="stat-val">KSh <?php echo number_format($total_revenue, 2); ?></div>
            <div class="stat-label">Verified Agro-Chemical Sales</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#e0f2fe; color:#0284c7; font-size: 0.85rem; font-weight:bold;">PKG</div>
        <div>
            <div class="stat-val"><?php echo $total_units_sold; ?></div>
            <div class="stat-label">Remedy Packages Dispatched</div>
        </div>
    </div>
</div>

<!-- Regional Outbreak Table & Top Selling Products -->
<div class="grid-2" style="margin-bottom: 24px;">
    <!-- Regional Outbreaks -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Prevalence by Kenyan County</h3>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>County</th>
                        <th>Scans Logged</th>
                        <th>Severe Infections</th>
                        <th>Risk Level</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($county_stats)): ?>
                        <tr><td colspan="4" style="text-align: center; color: var(--text-muted);">No scan data logged yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($county_stats as $cs): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($cs['county_name']); ?></strong></td>
                                <td><?php echo (int)$cs['total_scans']; ?></td>
                                <td style="color: <?php echo $cs['severe_outbreaks'] > 0 ? 'var(--danger)' : 'var(--success)'; ?>; font-weight: 600;">
                                    <?php echo (int)$cs['severe_outbreaks']; ?>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $cs['severe_outbreaks'] > 2 ? 'severe' : ($cs['severe_outbreaks'] > 0 ? 'moderate' : 'healthy'); ?>">
                                        <?php echo $cs['severe_outbreaks'] > 2 ? 'High Alert' : ($cs['severe_outbreaks'] > 0 ? 'Moderate' : 'Low Risk'); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Top Products Sold -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Top Requested Disease Remedies</h3>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Units Sold</th>
                        <th>Total Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($top_products)): ?>
                        <tr><td colspan="3" style="text-align: center; color: var(--text-muted);">No sales recorded yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($top_products as $tp): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($tp['product_name']); ?></strong></td>
                                <td><?php echo (int)$tp['units_sold']; ?> packs</td>
                                <td><strong>KSh <?php echo number_format($tp['total_sales'], 2); ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Disease Catalog Performance Audit -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Crop Disease Detection Frequency & Model Confidence</h3>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Crop</th>
                    <th>Disease Condition</th>
                    <th>Severity Category</th>
                    <th>Total Field Detections</th>
                    <th>Average AI Confidence</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($disease_stats as $ds): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($ds['crop_name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($ds['disease_name']); ?></td>
                        <td>
                            <span class="badge badge-<?php echo strtolower($ds['severity']); ?>">
                                <?php echo htmlspecialchars($ds['severity']); ?>
                            </span>
                        </td>
                        <td>
                            <strong><?php echo (int)$ds['detection_count']; ?></strong> times
                        </td>
                        <td>
                            <?php echo $ds['avg_confidence'] ? number_format($ds['avg_confidence'], 1) . '%' : 'N/A'; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
