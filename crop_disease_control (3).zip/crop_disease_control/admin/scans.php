<?php
// crop_disease_control/admin/scans.php
// Administrator Audit of All Diagnostic Scan Records

$depth = 1;
$base_prefix = '../';
$page_title = "All Diagnosis Scans";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

// Handle deletion of a scan record
if (isset($_GET['delete_id'])) {
    $del_id = (int)$_GET['delete_id'];
    try {
        $stmt_img = $pdo->prepare("
            SELECT i.image_path, p.id 
            FROM predictions p 
            JOIN images i ON p.image_id = i.id 
            WHERE p.id = ?
        ");
        $stmt_img->execute([$del_id]);
        $record = $stmt_img->fetch();

        if ($record) {
            $file_path = __DIR__ . '/../' . $record['image_path'];
            if (file_exists($file_path)) {
                @unlink($file_path);
            }
            $stmt_del = $pdo->prepare("DELETE FROM predictions WHERE id = ?");
            $stmt_del->execute([$del_id]);
            set_flash('success', 'Scan record deleted successfully.');
        }
    } catch (PDOException $e) {
        set_flash('danger', 'Error deleting record: ' . $e->getMessage());
    }
    header("Location: scans.php");
    exit;
}

// Filters
$filter_crop = sanitize($_GET['crop'] ?? '');
$filter_severity = sanitize($_GET['severity'] ?? '');
$search_q = sanitize($_GET['q'] ?? '');

$sql = "
    SELECT 
        p.id AS prediction_id,
        p.confidence,
        p.notes,
        p.created_at,
        i.image_path,
        i.crop_type,
        u.id AS farmer_id,
        u.name AS farmer_name,
        u.county AS farmer_county,
        d.disease_name,
        d.severity
    FROM predictions p
    JOIN images i ON p.image_id = i.id
    JOIN users u ON i.user_id = u.id
    JOIN diseases d ON p.disease_id = d.id
    WHERE 1=1
";
$params = [];

if (!empty($filter_crop)) {
    $sql .= " AND i.crop_type = ?";
    $params[] = $filter_crop;
}
if (!empty($filter_severity)) {
    $sql .= " AND d.severity = ?";
    $params[] = $filter_severity;
}
if (!empty($search_q)) {
    $sql .= " AND (u.name LIKE ? OR d.disease_name LIKE ? OR u.county LIKE ?)";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
}

$sql .= " ORDER BY p.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$all_scans = $stmt->fetchAll();

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div class="card">
    <div class="card-header" style="flex-wrap: wrap; gap: 10px;">
        <div>
            <h1 class="card-title">All Farm Diagnostic Scans Log</h1>
            <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
                Comprehensive record of leaf images analyzed by the AI engine nationwide.
            </p>
        </div>
        <div>
            <span class="badge badge-info" style="font-size: 0.9rem; padding: 6px 12px;">
                Total Logs: <?php echo count($all_scans); ?>
            </span>
        </div>
    </div>

    <!-- Filter Form -->
    <form method="GET" action="scans.php" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
        <select name="crop" class="form-control" style="width: auto; min-width: 140px;" onchange="this.form.submit()">
            <option value="">All Crops</option>
            <option value="Maize" <?php echo $filter_crop === 'Maize' ? 'selected' : ''; ?>>Maize</option>
            <option value="Tomato" <?php echo $filter_crop === 'Tomato' ? 'selected' : ''; ?>>Tomato</option>
            <option value="Potato" <?php echo $filter_crop === 'Potato' ? 'selected' : ''; ?>>Potato</option>
            <option value="Beans" <?php echo $filter_crop === 'Beans' ? 'selected' : ''; ?>>Beans</option>
        </select>

        <select name="severity" class="form-control" style="width: auto; min-width: 140px;" onchange="this.form.submit()">
            <option value="">All Severities</option>
            <option value="Healthy" <?php echo $filter_severity === 'Healthy' ? 'selected' : ''; ?>>Healthy</option>
            <option value="Low" <?php echo $filter_severity === 'Low' ? 'selected' : ''; ?>>Low</option>
            <option value="Moderate" <?php echo $filter_severity === 'Moderate' ? 'selected' : ''; ?>>Moderate</option>
            <option value="Severe" <?php echo $filter_severity === 'Severe' ? 'selected' : ''; ?>>Severe</option>
        </select>

        <input type="text" name="q" class="form-control" placeholder="Search farmer, county, or disease..." value="<?php echo htmlspecialchars($search_q); ?>" style="flex: 1; min-width: 200px;">

        <button type="submit" class="btn btn-outline btn-sm">Filter</button>
        <?php if (!empty($filter_crop) || !empty($filter_severity) || !empty($search_q)): ?>
            <a href="scans.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151;">Reset</a>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Leaf Image</th>
                    <th>Farmer Name</th>
                    <th>County</th>
                    <th>Crop</th>
                    <th>AI Diagnosed Disease</th>
                    <th>Confidence</th>
                    <th>Severity</th>
                    <th>Scan Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($all_scans)): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            No diagnostic scan records found matching query.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($all_scans as $scan): ?>
                        <tr>
                            <td>
                                <img src="../<?php echo htmlspecialchars($scan['image_path']); ?>" alt="Leaf" style="width: 50px; height: 50px; object-fit: cover; border-radius: 6px; border: 1px solid var(--border);">
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($scan['farmer_name']); ?></strong><br>
                                <span style="font-size: 0.78rem; color: var(--text-muted);">ID: #<?php echo $scan['farmer_id']; ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($scan['farmer_county'] ?: 'Kenya'); ?></td>
                            <td><strong><?php echo htmlspecialchars($scan['crop_type']); ?></strong></td>
                            <td>
                                <div style="font-weight: 600;"><?php echo htmlspecialchars($scan['disease_name']); ?></div>
                                <?php if (!empty($scan['notes'])): ?>
                                    <div style="font-size: 0.78rem; color: var(--text-muted);">
                                        Note: <?php echo htmlspecialchars($scan['notes']); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong style="color: var(--primary);"><?php echo number_format($scan['confidence'], 1); ?>%</strong>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo strtolower($scan['severity']); ?>">
                                    <?php echo htmlspecialchars($scan['severity']); ?>
                                </span>
                            </td>
                            <td style="font-size: 0.84rem; color: var(--text-muted);">
                                <?php echo date('M d, Y', strtotime($scan['created_at'])); ?><br>
                                <span style="font-size: 0.76rem;"><?php echo date('h:i A', strtotime($scan['created_at'])); ?></span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <a href="../farmer/report.php?id=<?php echo $scan['prediction_id']; ?>" class="btn btn-sm btn-outline" target="_blank">
                                        Report
                                    </a>
                                    <a href="scans.php?delete_id=<?php echo $scan['prediction_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this scan entry permanently?');">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
