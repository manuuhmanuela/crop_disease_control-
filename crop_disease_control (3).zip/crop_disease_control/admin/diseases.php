<?php
// crop_disease_control/admin/diseases.php
// Admin Crop Disease Knowledgebase Management (CRUD)

$depth = 1;
$base_prefix = '../';
$page_title = "Manage Crop Diseases";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);
$edit_disease = null;

// Handle Delete
if ($action === 'delete' && $edit_id > 0) {
    try {
        $stmt = $pdo->prepare("DELETE FROM diseases WHERE id = ?");
        $stmt->execute([$edit_id]);
        set_flash('success', 'Disease record removed from knowledgebase.');
    } catch (PDOException $e) {
        set_flash('danger', 'Cannot delete this disease because existing predictions reference it: ' . $e->getMessage());
    }
    header("Location: diseases.php");
    exit;
}

// Handle Add or Edit Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $crop_name = sanitize($_POST['crop_name'] ?? '');
    $disease_name = sanitize($_POST['disease_name'] ?? '');
    $symptoms = sanitize($_POST['symptoms'] ?? '');
    $causes = sanitize($_POST['causes'] ?? '');
    $treatment = sanitize($_POST['treatment'] ?? '');
    $prevention = sanitize($_POST['prevention'] ?? '');
    $severity = sanitize($_POST['severity'] ?? 'Moderate');
    $save_id = (int)($_POST['disease_id'] ?? 0);

    if (empty($crop_name) || empty($disease_name) || empty($symptoms) || empty($treatment)) {
        set_flash('danger', 'Please provide Crop Name, Disease Name, Symptoms, and Treatment.');
    } else {
        try {
            if ($save_id > 0) {
                $stmt = $pdo->prepare("
                    UPDATE diseases 
                    SET crop_name = ?, disease_name = ?, symptoms = ?, causes = ?, treatment = ?, prevention = ?, severity = ?
                    WHERE id = ?
                ");
                $stmt->execute([$crop_name, $disease_name, $symptoms, $causes, $treatment, $prevention, $severity, $save_id]);
                set_flash('success', "Updated disease record for '{$disease_name}'.");
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO diseases (crop_name, disease_name, symptoms, causes, treatment, prevention, severity)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$crop_name, $disease_name, $symptoms, $causes, $treatment, $prevention, $severity]);
                set_flash('success', "Added new disease '{$disease_name}' to dataset.");
            }
            header("Location: diseases.php");
            exit;
        } catch (PDOException $e) {
            set_flash('danger', 'Database error: ' . $e->getMessage());
        }
    }
}

// If editing, load record
if ($action === 'edit' && $edit_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM diseases WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_disease = $stmt->fetch();
}

// Filters & Listing
$filter_crop = sanitize($_GET['crop'] ?? '');
$search_q = sanitize($_GET['q'] ?? '');

$sql = "SELECT * FROM diseases WHERE 1=1";
$params = [];

if (!empty($filter_crop)) {
    $sql .= " AND crop_name = ?";
    $params[] = $filter_crop;
}
if (!empty($search_q)) {
    $sql .= " AND (disease_name LIKE ? OR symptoms LIKE ?)";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
}
$sql .= " ORDER BY crop_name ASC, disease_name ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$diseases = $stmt->fetchAll();

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
    <div>
        <h1 class="card-title" style="font-size: 1.6rem;">Disease Knowledgebase Database</h1>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
            Manage crop diseases, symptomatic features, and agronomic prescriptions.
        </p>
    </div>
    <a href="<?php echo ($action === 'add' || $action === 'edit') ? 'diseases.php' : 'diseases.php?action=add'; ?>" class="btn btn-primary btn-sm">
        <?php echo ($action === 'add' || $action === 'edit') ? 'Back to List' : 'Add New Disease'; ?>
    </a>
</div>

<?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- ADD / EDIT FORM -->
    <div class="card" style="border-top: 4px solid var(--primary); max-width: 800px; margin: 0 auto 30px auto;">
        <div class="card-header">
            <h2 class="card-title">
                <?php echo $edit_disease ? 'Edit Disease Record: ' . htmlspecialchars($edit_disease['disease_name']) : 'Register New Crop Disease Profile'; ?>
            </h2>
        </div>

        <form method="POST" action="diseases.php">
            <input type="hidden" name="disease_id" value="<?php echo $edit_disease['id'] ?? 0; ?>">

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label" for="crop_name">Crop Variety *</label>
                    <select name="crop_name" id="crop_name" class="form-control" required>
                        <?php 
                        $crops = ['Maize', 'Tomato', 'Potato', 'Beans'];
                        $current_crop = $edit_disease['crop_name'] ?? 'Maize';
                        foreach ($crops as $c) {
                            $sel = ($current_crop === $c) ? 'selected' : '';
                            echo "<option value=\"$c\" $sel>$c</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="severity">Severity Assessment *</label>
                    <select name="severity" id="severity" class="form-control" required>
                        <?php 
                        $sevs = ['Healthy', 'Low', 'Moderate', 'Severe'];
                        $current_sev = $edit_disease['severity'] ?? 'Moderate';
                        foreach ($sevs as $s) {
                            $sel = ($current_sev === $s) ? 'selected' : '';
                            echo "<option value=\"$s\" $sel>$s</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="disease_name">Disease Name / Botanical Condition *</label>
                <input type="text" name="disease_name" id="disease_name" class="form-control" placeholder="e.g. Tomato Late Blight (Phytophthora infestans)" value="<?php echo htmlspecialchars($edit_disease['disease_name'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label" for="symptoms">Visual Leaf Symptoms *</label>
                <textarea name="symptoms" id="symptoms" class="form-control" rows="3" placeholder="Describe spots, halo colors, pustules, leaf curling..." required><?php echo htmlspecialchars($edit_disease['symptoms'] ?? ''); ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label" for="causes">Pathogen / Causative Agent *</label>
                <textarea name="causes" id="causes" class="form-control" rows="2" placeholder="Fungus / Bacteria / Virus / Environmental vector..." required><?php echo htmlspecialchars($edit_disease['causes'] ?? ''); ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label" for="treatment">Recommended Treatment (Chemical & Organic) *</label>
                <textarea name="treatment" id="treatment" class="form-control" rows="3" placeholder="Fungicide formulations, biopesticides, rogued plants disposal..." required><?php echo htmlspecialchars($edit_disease['treatment'] ?? ''); ?></textarea>
            </div>

            <div class="form-group">
                <label class="form-label" for="prevention">Preventive Measures & Cultural Practices *</label>
                <textarea name="prevention" id="prevention" class="form-control" rows="3" placeholder="Spacing, certified seeds, crop rotation, irrigation management..." required><?php echo htmlspecialchars($edit_disease['prevention'] ?? ''); ?></textarea>
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <a href="diseases.php" class="btn btn-outline">Cancel</a>
                <button type="submit" class="btn btn-primary">
                    <?php echo $edit_disease ? 'Save Changes' : 'Create Disease Record'; ?>
                </button>
            </div>
        </form>
    </div>
<?php endif; ?>

<!-- LIST VIEW -->
<div class="card">
    <div class="card-header" style="flex-wrap: wrap; gap: 10px;">
        <h3 class="card-title">Registered Disease Catalog (<?php echo count($diseases); ?> Records)</h3>
    </div>

    <!-- Filter form -->
    <form method="GET" action="diseases.php" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
        <select name="crop" class="form-control" style="width: auto; min-width: 150px;" onchange="this.form.submit()">
            <option value="">All Crops</option>
            <option value="Maize" <?php echo $filter_crop === 'Maize' ? 'selected' : ''; ?>>Maize</option>
            <option value="Tomato" <?php echo $filter_crop === 'Tomato' ? 'selected' : ''; ?>>Tomato</option>
            <option value="Potato" <?php echo $filter_crop === 'Potato' ? 'selected' : ''; ?>>Potato</option>
            <option value="Beans" <?php echo $filter_crop === 'Beans' ? 'selected' : ''; ?>>Beans</option>
        </select>

        <input type="text" name="q" class="form-control" placeholder="Search disease or symptom..." value="<?php echo htmlspecialchars($search_q); ?>" style="flex: 1; min-width: 200px;">

        <button type="submit" class="btn btn-outline btn-sm">Filter</button>
        <?php if (!empty($filter_crop) || !empty($search_q)): ?>
            <a href="diseases.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151;">Reset</a>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Crop</th>
                    <th>Disease Name</th>
                    <th>Severity</th>
                    <th>Symptoms Summary</th>
                    <th>Treatment Preview</th>
                    <th style="min-width: 120px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($diseases)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 25px;">
                            No diseases found matching query.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($diseases as $d): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($d['crop_name']); ?></strong></td>
                            <td style="font-weight: 600;"><?php echo htmlspecialchars($d['disease_name']); ?></td>
                            <td>
                                <span class="badge badge-<?php echo strtolower($d['severity']); ?>">
                                    <?php echo htmlspecialchars($d['severity']); ?>
                                </span>
                            </td>
                            <td style="font-size: 0.85rem; max-width: 260px; color: var(--text-muted);">
                                <?php echo htmlspecialchars(mb_strimwidth($d['symptoms'], 0, 95, '...')); ?>
                            </td>
                            <td style="font-size: 0.85rem; max-width: 260px; color: var(--text-muted);">
                                <?php echo htmlspecialchars(mb_strimwidth($d['treatment'], 0, 95, '...')); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <a href="diseases.php?action=edit&id=<?php echo $d['id']; ?>" class="btn btn-sm btn-outline">
                                        Edit
                                    </a>
                                    <a href="diseases.php?action=delete&id=<?php echo $d['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this disease profile? Existing diagnostic reports referencing it may be affected.');">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
