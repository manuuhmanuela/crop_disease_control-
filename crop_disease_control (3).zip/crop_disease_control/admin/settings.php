<?php
// crop_disease_control/admin/settings.php
// Administrator System Configuration and Backup Utilities

$depth = 1;
$base_prefix = '../';
$page_title = "System Settings & Configuration";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

// Handle Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $site_name = sanitize($_POST['site_name'] ?? 'AgriShield AI Crop Protection');
    $support_phone = sanitize($_POST['support_phone'] ?? '+254 712 345 678');
    $support_email = sanitize($_POST['support_email'] ?? 'support@cropai.ke');
    $shipping_flat_rate = (float)($_POST['shipping_flat_rate'] ?? 250.00);
    $mpesa_till_number = sanitize($_POST['mpesa_till_number'] ?? '5829104');

    try {
        $settings_to_save = [
            'site_name' => $site_name,
            'support_phone' => $support_phone,
            'support_email' => $support_email,
            'shipping_flat_rate' => number_format($shipping_flat_rate, 2, '.', ''),
            'mpesa_till_number' => $mpesa_till_number,
        ];

        $stmt_set = $pdo->prepare("
            INSERT INTO `system_settings` (`setting_key`, `setting_value`) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`)
        ");

        foreach ($settings_to_save as $key => $val) {
            $stmt_set->execute([$key, $val]);
        }

        set_flash('success', 'System parameters and e-commerce settings saved successfully.');
    } catch (PDOException $e) {
        set_flash('danger', 'Failed saving settings: ' . $e->getMessage());
    }

    header("Location: settings.php");
    exit;
}

// Fetch Current Settings
$current_settings = [];
try {
    $stmt = $pdo->query("SELECT * FROM `system_settings`");
    while ($row = $stmt->fetch()) {
        $current_settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (PDOException $e) {}

$site_name = $current_settings['site_name'] ?? 'AgriShield AI Crop Protection';
$support_phone = $current_settings['support_phone'] ?? '+254 712 345 678';
$support_email = $current_settings['support_email'] ?? 'support@cropai.ke';
$shipping_rate = $current_settings['shipping_flat_rate'] ?? '250.00';
$mpesa_till = $current_settings['mpesa_till_number'] ?? '5829104';

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="max-width: 800px; margin: 0 auto;">

    <div style="margin-bottom: 24px;">
        <h1 class="card-title" style="font-size: 1.6rem;">System Configuration & E-Commerce Settings</h1>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
            Manage platform variables, M-Pesa till credentials, shipping fee, and maintenance utilities.
        </p>
    </div>

    <!-- Settings Form -->
    <div class="card" style="border-top: 4px solid var(--primary); margin-bottom: 24px;">
        <div class="card-header">
            <h2 class="card-title" style="font-size: 1.2rem;">Platform & Payment Parameters</h2>
        </div>

        <form method="POST" action="settings.php">
            <input type="hidden" name="save_settings" value="1">

            <div class="form-group">
                <label class="form-label" for="site_name">Platform Name</label>
                <input type="text" name="site_name" id="site_name" class="form-control" value="<?php echo htmlspecialchars($site_name); ?>" required>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label" for="support_phone">Farmer Helpline Phone Number</label>
                    <input type="tel" name="support_phone" id="support_phone" class="form-control" value="<?php echo htmlspecialchars($support_phone); ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="support_email">Support Desk Email</label>
                    <input type="email" name="support_email" id="support_email" class="form-control" value="<?php echo htmlspecialchars($support_email); ?>" required>
                </div>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label" for="mpesa_till_number">M-Pesa Buy Goods Till Number</label>
                    <input type="text" name="mpesa_till_number" id="mpesa_till_number" class="form-control" value="<?php echo htmlspecialchars($mpesa_till); ?>" required>
                    <small style="color: var(--text-muted);">Displayed on checkout for direct mobile money payments.</small>
                </div>

                <div class="form-group">
                    <label class="form-label" for="shipping_flat_rate">Countrywide Delivery Flat Rate (KSh)</label>
                    <input type="number" step="0.01" name="shipping_flat_rate" id="shipping_flat_rate" class="form-control" value="<?php echo htmlspecialchars($shipping_rate); ?>" required>
                    <small style="color: var(--text-muted);">Standard flat rate added to farmer parcel consignments.</small>
                </div>
            </div>

            <div style="display: flex; justify-content: flex-end; margin-top: 10px;">
                <button type="submit" class="btn btn-primary">
                    Save System Settings
                </button>
            </div>
        </form>
    </div>

    <!-- Maintenance & Database Tools -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title" style="font-size: 1.15rem;">Database & Maintenance Utilities</h3>
        </div>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin-bottom: 16px;">
            Mount Kenya University system maintenance and database synchronization tools.
        </p>

        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
            <a href="../install.php" class="btn btn-outline btn-sm">
                Re-Run Database Installer
            </a>
            <a href="../database.sql" class="btn btn-outline btn-sm" download>
                Download SQL Schema File
            </a>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
