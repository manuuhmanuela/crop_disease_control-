<?php
// crop_disease_control/admin/messages.php
// Administrator Support Desk (Manage Farmer Inquiries & Contact Messages)

$depth = 1;
$base_prefix = '../';
$page_title = "Farmer Support Messages";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

// Handle Status & Resolution Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_msg'])) {
    $msg_id = (int)$_POST['msg_id'];
    $status = sanitize($_POST['status'] ?? 'Read');
    $admin_notes = sanitize($_POST['admin_notes'] ?? '');

    try {
        $stmt_up = $pdo->prepare("UPDATE `contact_messages` SET `status` = ?, `admin_notes` = ? WHERE `id` = ?");
        $stmt_up->execute([$status, $admin_notes, $msg_id]);
        set_flash('success', "Inquiry #{$msg_id} status updated to '{$status}'.");
    } catch (PDOException $e) {
        set_flash('danger', "Error updating inquiry: " . $e->getMessage());
    }
    header("Location: messages.php");
    exit;
}

// Handle Delete Message
if (isset($_GET['delete_id'])) {
    $del_id = (int)$_GET['delete_id'];
    try {
        $stmt_del = $pdo->prepare("DELETE FROM `contact_messages` WHERE `id` = ?");
        $stmt_del->execute([$del_id]);
        set_flash('success', "Support message removed.");
    } catch (PDOException $e) {
        set_flash('danger', "Error deleting message: " . $e->getMessage());
    }
    header("Location: messages.php");
    exit;
}

// Filters & Search
$filter_status = sanitize($_GET['status'] ?? '');
$search_q = sanitize($_GET['q'] ?? '');

$sql = "SELECT * FROM `contact_messages` WHERE 1=1";
$params = [];

if (!empty($filter_status)) {
    $sql .= " AND `status` = ?";
    $params[] = $filter_status;
}
if (!empty($search_q)) {
    $sql .= " AND (`name` LIKE ? OR `email` LIKE ? OR `subject` LIKE ? OR `message` LIKE ?)";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
}

$sql .= " ORDER BY `id` DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$messages = $stmt->fetchAll();

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
    <div>
        <h1 class="card-title" style="font-size: 1.6rem;">Farmer Contact & Support Messages</h1>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
            Review incoming inquiries, field queries, and requests for extension advice.
        </p>
    </div>
    <span class="badge badge-info" style="font-size: 0.9rem; padding: 6px 14px;">
        Total Inquiries: <?php echo count($messages); ?>
    </span>
</div>

<!-- Filter Bar -->
<div class="card" style="margin-bottom: 24px; padding: 18px;">
    <form method="GET" action="messages.php" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
        <select name="status" class="form-control" style="width: auto; min-width: 140px;" onchange="this.form.submit()">
            <option value="">All Statuses</option>
            <option value="New" <?php echo $filter_status === 'New' ? 'selected' : ''; ?>>New Inquiries</option>
            <option value="Read" <?php echo $filter_status === 'Read' ? 'selected' : ''; ?>>Read</option>
            <option value="Replied" <?php echo $filter_status === 'Replied' ? 'selected' : ''; ?>>Replied</option>
        </select>

        <input type="text" name="q" class="form-control" placeholder="Search sender, email, subject, or question..." value="<?php echo htmlspecialchars($search_q); ?>" style="flex: 1; min-width: 220px;">

        <button type="submit" class="btn btn-outline btn-sm">Filter</button>
        <?php if (!empty($filter_status) || !empty($search_q)): ?>
            <a href="messages.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151;">Reset</a>
        <?php endif; ?>
    </form>
</div>

<!-- Messages List -->
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Sender Name</th>
                    <th>Contact Info</th>
                    <th>Subject</th>
                    <th>Message Snippet</th>
                    <th>Status</th>
                    <th>Date Received</th>
                    <th>Manage</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($messages)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            No support inquiries found.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($messages as $msg): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($msg['name']); ?></strong></td>
                            <td style="font-size: 0.85rem;">
                                <?php echo htmlspecialchars($msg['email']); ?><br>
                                <span style="color: var(--text-muted);"><?php echo htmlspecialchars($msg['phone'] ?: 'No phone provided'); ?></span>
                            </td>
                            <td><strong><?php echo htmlspecialchars($msg['subject']); ?></strong></td>
                            <td style="font-size: 0.85rem; max-width: 250px; color: #4b5563;">
                                <?php echo htmlspecialchars(mb_strimwidth($msg['message'], 0, 85, '...')); ?>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $msg['status'] === 'New' ? 'severe' : ($msg['status'] === 'Replied' ? 'healthy' : 'moderate'); ?>">
                                    <?php echo htmlspecialchars($msg['status']); ?>
                                </span>
                            </td>
                            <td style="font-size: 0.82rem; color: var(--text-muted);">
                                <?php echo date('M d, Y', strtotime($msg['created_at'])); ?>
                            </td>
                            <td>
                                <button type="button" onclick="document.getElementById('msgDrawer_<?php echo $msg['id']; ?>').style.display='block';" class="btn btn-sm btn-primary" style="padding: 3px 8px; font-size: 0.8rem;">
                                    View & Reply
                                </button>
                            </td>
                        </tr>

                        <!-- Message Detail Drawer -->
                        <tr id="msgDrawer_<?php echo $msg['id']; ?>" style="display: none; background: #f8fafc;">
                            <td colspan="7" style="padding: 20px;">
                                <div style="border: 1px solid var(--border); background: #fff; padding: 20px; border-radius: 8px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid var(--border); padding-bottom: 8px;">
                                        <h4 style="margin: 0; color: var(--primary-dark);">
                                            Inquiry from <?php echo htmlspecialchars($msg['name']); ?> &bull; <?php echo htmlspecialchars($msg['subject']); ?>
                                        </h4>
                                        <button type="button" onclick="document.getElementById('msgDrawer_<?php echo $msg['id']; ?>').style.display='none';" class="btn btn-sm" style="background:#e2e8f0;">Close</button>
                                    </div>

                                    <div style="background: #f1f5f9; padding: 14px; border-radius: 6px; font-size: 0.92rem; line-height: 1.6; margin-bottom: 16px;">
                                        <strong>Full Question:</strong><br>
                                        <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
                                    </div>

                                    <form method="POST" action="messages.php">
                                        <input type="hidden" name="update_msg" value="1">
                                        <input type="hidden" name="msg_id" value="<?php echo $msg['id']; ?>">

                                        <div class="grid-2">
                                            <div class="form-group">
                                                <label class="form-label" for="status_<?php echo $msg['id']; ?>">Status</label>
                                                <select name="status" id="status_<?php echo $msg['id']; ?>" class="form-control">
                                                    <option value="New" <?php echo $msg['status'] === 'New' ? 'selected' : ''; ?>>New</option>
                                                    <option value="Read" <?php echo $msg['status'] === 'Read' ? 'selected' : ''; ?>>Read</option>
                                                    <option value="Replied" <?php echo $msg['status'] === 'Replied' ? 'selected' : ''; ?>>Replied</option>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="form-label" for="admin_notes_<?php echo $msg['id']; ?>">Agronomist Response / Resolution Notes</label>
                                                <input type="text" name="admin_notes" id="admin_notes_<?php echo $msg['id']; ?>" class="form-control" value="<?php echo htmlspecialchars($msg['admin_notes'] ?? ''); ?>" placeholder="e.g. Advised farmer via phone on Mancozeb spray schedule">
                                            </div>
                                        </div>

                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <a href="messages.php?delete_id=<?php echo $msg['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this support message?');">
                                                Delete Message
                                            </a>
                                            <button type="submit" class="btn btn-primary btn-sm">
                                                Save Notes & Status
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
