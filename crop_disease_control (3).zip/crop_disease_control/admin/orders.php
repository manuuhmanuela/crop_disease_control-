<?php
// crop_disease_control/admin/orders.php
// Administrator Order Management (View & Update Farmer Orders)

$depth = 1;
$base_prefix = '../';
$page_title = "Manage Customer Orders";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

// Handle Status & Payment Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_order'])) {
    $order_id = (int)$_POST['order_id'];
    $order_status = sanitize($_POST['order_status'] ?? 'Pending');
    $payment_status = sanitize($_POST['payment_status'] ?? 'Pending');
    $tracking_number = sanitize($_POST['tracking_number'] ?? '');
    $admin_notes = sanitize($_POST['notes'] ?? '');

    try {
        $stmt_up = $pdo->prepare("
            UPDATE `orders` 
            SET `order_status` = ?, `payment_status` = ?, `tracking_number` = ?, `notes` = ?
            WHERE `id` = ?
        ");
        $stmt_up->execute([$order_status, $payment_status, $tracking_number, $admin_notes, $order_id]);
        set_flash('success', "Order #{$order_id} fulfillment and payment status updated.");
    } catch (PDOException $e) {
        set_flash('danger', "Error updating order: " . $e->getMessage());
    }
    header("Location: orders.php");
    exit;
}

// Handle Delete Order
if (isset($_GET['delete_id'])) {
    $del_id = (int)$_GET['delete_id'];
    try {
        $stmt_del = $pdo->prepare("DELETE FROM `orders` WHERE `id` = ?");
        $stmt_del->execute([$del_id]);
        set_flash('success', "Order record removed.");
    } catch (PDOException $e) {
        set_flash('danger', "Error deleting order: " . $e->getMessage());
    }
    header("Location: orders.php");
    exit;
}

// Filters & Search
$filter_status = sanitize($_GET['order_status'] ?? '');
$filter_payment = sanitize($_GET['payment_status'] ?? '');
$search_q = sanitize($_GET['q'] ?? '');

$sql = "
    SELECT 
        o.*,
        u.name AS farmer_account_name,
        u.email AS farmer_email
    FROM `orders` o
    LEFT JOIN `users` u ON o.user_id = u.id
    WHERE 1=1
";
$params = [];

if (!empty($filter_status)) {
    $sql .= " AND o.`order_status` = ?";
    $params[] = $filter_status;
}
if (!empty($filter_payment)) {
    $sql .= " AND o.`payment_status` = ?";
    $params[] = $filter_payment;
}
if (!empty($search_q)) {
    $sql .= " AND (o.`order_number` LIKE ? OR o.`tracking_number` LIKE ? OR o.`shipping_name` LIKE ? OR o.`shipping_phone` LIKE ?)";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
}

$sql .= " ORDER BY o.`id` DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Pre-load all order items grouped by order_id
$order_items_map = [];
$stmt_all_items = $pdo->query("SELECT * FROM `order_items`");
while ($row = $stmt_all_items->fetch()) {
    $order_items_map[$row['order_id']][] = $row;
}

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
    <div>
        <h1 class="card-title" style="font-size: 1.6rem;">Farmer Agro-Chemical Orders Management</h1>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
            Track consignments, update fulfillment status, and verify farmer M-Pesa payments.
        </p>
    </div>
    <span class="badge badge-info" style="font-size: 0.9rem; padding: 6px 14px;">
        Total Orders: <?php echo count($orders); ?>
    </span>
</div>

<!-- Filter Bar -->
<div class="card" style="margin-bottom: 24px; padding: 18px;">
    <form method="GET" action="orders.php" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
        <select name="order_status" class="form-control" style="width: auto; min-width: 150px;" onchange="this.form.submit()">
            <option value="">All Order Statuses</option>
            <option value="Pending" <?php echo $filter_status === 'Pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="Processing" <?php echo $filter_status === 'Processing' ? 'selected' : ''; ?>>Processing</option>
            <option value="Dispatched" <?php echo $filter_status === 'Dispatched' ? 'selected' : ''; ?>>Dispatched</option>
            <option value="Delivered" <?php echo $filter_status === 'Delivered' ? 'selected' : ''; ?>>Delivered</option>
            <option value="Cancelled" <?php echo $filter_status === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
        </select>

        <select name="payment_status" class="form-control" style="width: auto; min-width: 150px;" onchange="this.form.submit()">
            <option value="">All Payment Statuses</option>
            <option value="Pending" <?php echo $filter_payment === 'Pending' ? 'selected' : ''; ?>>Pending Payment</option>
            <option value="Paid" <?php echo $filter_payment === 'Paid' ? 'selected' : ''; ?>>Paid</option>
            <option value="Failed" <?php echo $filter_payment === 'Failed' ? 'selected' : ''; ?>>Failed</option>
        </select>

        <input type="text" name="q" class="form-control" placeholder="Search order ref, tracking code, recipient or phone..." value="<?php echo htmlspecialchars($search_q); ?>" style="flex: 1; min-width: 220px;">

        <button type="submit" class="btn btn-outline btn-sm">Filter</button>
        <?php if (!empty($filter_status) || !empty($filter_payment) || !empty($search_q)): ?>
            <a href="orders.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151;">Reset</a>
        <?php endif; ?>
    </form>
</div>

<!-- Orders Table -->
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Order Ref</th>
                    <th>Farmer Recipient</th>
                    <th>Destination</th>
                    <th>Amount (KSh)</th>
                    <th>Payment</th>
                    <th>Fulfillment</th>
                    <th>Date</th>
                    <th style="min-width: 140px;">Manage</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            No orders found matching the filter criteria.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($orders as $ord): 
                        $items = $order_items_map[$ord['id']] ?? [];
                    ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($ord['order_number']); ?></strong><br>
                                <span style="font-size: 0.78rem; color: var(--text-muted);"><?php echo htmlspecialchars($ord['tracking_number']); ?></span>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($ord['shipping_name']); ?></strong><br>
                                <span style="font-size: 0.78rem; color: var(--text-muted);"><?php echo htmlspecialchars($ord['shipping_phone']); ?></span>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($ord['shipping_county']); ?><br>
                                <span style="font-size: 0.76rem; color: var(--text-muted);"><?php echo htmlspecialchars(mb_strimwidth($ord['shipping_address'], 0, 30, '...')); ?></span>
                            </td>
                            <td>
                                <strong>KSh <?php echo number_format($ord['total_amount'], 2); ?></strong>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $ord['payment_status'] === 'Paid' ? 'healthy' : 'moderate'; ?>">
                                    <?php echo htmlspecialchars($ord['payment_status']); ?>
                                </span><br>
                                <span style="font-size: 0.74rem; color: var(--text-muted);"><?php echo htmlspecialchars($ord['payment_method']); ?></span>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $ord['order_status'] === 'Delivered' ? 'healthy' : ($ord['order_status'] === 'Dispatched' ? 'info' : 'moderate'); ?>">
                                    <?php echo htmlspecialchars($ord['order_status']); ?>
                                </span>
                            </td>
                            <td style="font-size: 0.82rem; color: var(--text-muted);">
                                <?php echo date('M d, Y', strtotime($ord['created_at'])); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 4px; flex-direction: column;">
                                    <button type="button" onclick="document.getElementById('editBox_<?php echo $ord['id']; ?>').style.display='block';" class="btn btn-sm btn-primary" style="padding: 4px 8px; font-size: 0.8rem;">
                                        Update Order
                                    </button>
                                    <a href="../track_order.php?order_number=<?php echo urlencode($ord['order_number']); ?>" class="btn btn-sm btn-outline" target="_blank" style="padding: 3px 6px; font-size: 0.78rem; text-align: center;">
                                        Track View
                                    </a>
                                </div>
                            </td>
                        </tr>

                        <!-- In-Page Order Update Drawer / Modal -->
                        <tr id="editBox_<?php echo $ord['id']; ?>" style="display: none; background: #f8fafc;">
                            <td colspan="8" style="padding: 20px;">
                                <div style="border: 1px solid var(--border); background: #fff; padding: 20px; border-radius: 8px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; border-bottom: 1px solid var(--border); padding-bottom: 8px;">
                                        <h4 style="margin: 0; color: var(--primary-dark);">
                                            Update Order #<?php echo htmlspecialchars($ord['order_number']); ?> (Recipient: <?php echo htmlspecialchars($ord['shipping_name']); ?>)
                                        </h4>
                                        <button type="button" onclick="document.getElementById('editBox_<?php echo $ord['id']; ?>').style.display='none';" class="btn btn-sm" style="background:#e2e8f0;">Close</button>
                                    </div>

                                    <!-- Items in this order -->
                                    <div style="margin-bottom: 16px;">
                                        <strong style="font-size: 0.85rem; color: var(--secondary);">Items Ordered:</strong>
                                        <ul style="margin: 6px 0 0 20px; font-size: 0.86rem; color: #374151;">
                                            <?php foreach ($items as $it): ?>
                                                <li><?php echo htmlspecialchars($it['product_name']); ?> &mdash; <?php echo $it['quantity']; ?> unit(s) &times; KSh <?php echo number_format($it['price'], 2); ?> = <strong>KSh <?php echo number_format($it['subtotal'], 2); ?></strong></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>

                                    <form method="POST" action="orders.php">
                                        <input type="hidden" name="update_order" value="1">
                                        <input type="hidden" name="order_id" value="<?php echo $ord['id']; ?>">

                                        <div class="grid-3">
                                            <div class="form-group">
                                                <label class="form-label" for="order_status_<?php echo $ord['id']; ?>">Order Fulfillment Status</label>
                                                <select name="order_status" id="order_status_<?php echo $ord['id']; ?>" class="form-control">
                                                    <?php 
                                                    $statuses = ['Pending', 'Processing', 'Dispatched', 'Delivered', 'Cancelled'];
                                                    foreach ($statuses as $st) {
                                                        $sel = ($ord['order_status'] === $st) ? 'selected' : '';
                                                        echo "<option value=\"$st\" $sel>$st</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="form-label" for="payment_status_<?php echo $ord['id']; ?>">Payment Status</label>
                                                <select name="payment_status" id="payment_status_<?php echo $ord['id']; ?>" class="form-control">
                                                    <?php 
                                                    $p_statuses = ['Pending', 'Paid', 'Failed'];
                                                    foreach ($p_statuses as $pst) {
                                                        $sel = ($ord['payment_status'] === $pst) ? 'selected' : '';
                                                        echo "<option value=\"$pst\" $sel>$pst</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="form-label" for="tracking_number_<?php echo $ord['id']; ?>">Tracking Number</label>
                                                <input type="text" name="tracking_number" id="tracking_number_<?php echo $ord['id']; ?>" class="form-control" value="<?php echo htmlspecialchars($ord['tracking_number']); ?>">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="form-label" for="notes_<?php echo $ord['id']; ?>">Courier & Dispatch Notes</label>
                                            <input type="text" name="notes" id="notes_<?php echo $ord['id']; ?>" class="form-control" value="<?php echo htmlspecialchars($ord['notes'] ?? ''); ?>" placeholder="e.g. Dispatched via Fargo Courier Waybill #8821">
                                        </div>

                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <a href="orders.php?delete_id=<?php echo $ord['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this order record permanently?');">
                                                Delete Order
                                            </a>
                                            <button type="submit" class="btn btn-primary btn-sm">
                                                Save Order Updates
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
