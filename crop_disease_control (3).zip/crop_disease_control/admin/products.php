<?php
// crop_disease_control/admin/products.php
// Administrator Product Management (Pest & Disease Control Products CRUD)

$depth = 1;
$base_prefix = '../';
$page_title = "Manage Products";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

$action = $_GET['action'] ?? 'list';
$edit_id = (int)($_GET['id'] ?? 0);
$edit_product = null;

// Handle Delete
if ($action === 'delete' && $edit_id > 0) {
    try {
        $stmt = $pdo->prepare("DELETE FROM `products` WHERE `id` = ?");
        $stmt->execute([$edit_id]);
        set_flash('success', 'Product removed from catalog.');
    } catch (PDOException $e) {
        set_flash('danger', 'Cannot delete product: ' . $e->getMessage());
    }
    header("Location: products.php");
    exit;
}

// Handle Add or Edit Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $category = sanitize($_POST['category'] ?? 'Fungicide');
    $target_crop = sanitize($_POST['target_crop'] ?? 'All Crops');
    $target_disease = sanitize($_POST['target_disease'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $dosage = sanitize($_POST['dosage'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $stock_quantity = (int)($_POST['stock_quantity'] ?? 0);
    $save_id = (int)($_POST['product_id'] ?? 0);

    if (empty($name) || empty($description) || $price <= 0) {
        set_flash('danger', 'Please provide Product Name, Description, and a valid Price.');
    } else {
        try {
            if ($save_id > 0) {
                $stmt = $pdo->prepare("
                    UPDATE `products` 
                    SET `name` = ?, `category` = ?, `target_crop` = ?, `target_disease` = ?, 
                        `description` = ?, `dosage` = ?, `price` = ?, `stock_quantity` = ?
                    WHERE `id` = ?
                ");
                $stmt->execute([$name, $category, $target_crop, $target_disease, $description, $dosage, $price, $stock_quantity, $save_id]);
                set_flash('success', "Updated product '{$name}'.");
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO `products` (`name`, `category`, `target_crop`, `target_disease`, `description`, `dosage`, `price`, `stock_quantity`)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$name, $category, $target_crop, $target_disease, $description, $dosage, $price, $stock_quantity]);
                set_flash('success', "Added new product '{$name}' to catalog.");
            }
            header("Location: products.php");
            exit;
        } catch (PDOException $e) {
            set_flash('danger', 'Database error: ' . $e->getMessage());
        }
    }
}

// If editing, load record
if ($action === 'edit' && $edit_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM `products` WHERE `id` = ?");
    $stmt->execute([$edit_id]);
    $edit_product = $stmt->fetch();
}

// Filters & Listing
$filter_cat = sanitize($_GET['category'] ?? '');
$search_q = sanitize($_GET['q'] ?? '');

$sql = "SELECT * FROM `products` WHERE 1=1";
$params = [];

if (!empty($filter_cat)) {
    $sql .= " AND `category` = ?";
    $params[] = $filter_cat;
}
if (!empty($search_q)) {
    $sql .= " AND (`name` LIKE ? OR `target_disease` LIKE ? OR `target_crop` LIKE ?)";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
}
$sql .= " ORDER BY `id` DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
    <div>
        <h1 class="card-title" style="font-size: 1.6rem;">Pest & Disease Control Products Management</h1>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
            Add, edit, adjust inventory stock and pricing for agricultural control products.
        </p>
    </div>
    <div style="display: flex; gap: 8px;">
        <a href="../shop.php" class="btn btn-outline btn-sm" target="_blank">View Live Shop</a>
        <a href="<?php echo ($action === 'add' || $action === 'edit') ? 'products.php' : 'products.php?action=add'; ?>" class="btn btn-primary btn-sm">
            <?php echo ($action === 'add' || $action === 'edit') ? 'Back to Products' : 'Add New Product'; ?>
        </a>
    </div>
</div>

<?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- ADD / EDIT FORM -->
    <div class="card" style="border-top: 4px solid var(--primary); max-width: 800px; margin: 0 auto 30px auto;">
        <div class="card-header">
            <h2 class="card-title">
                <?php echo $edit_product ? 'Edit Product: ' . htmlspecialchars($edit_product['name']) : 'Register New Agro-Chemical / Equipment Product'; ?>
            </h2>
        </div>

        <form method="POST" action="products.php">
            <input type="hidden" name="product_id" value="<?php echo $edit_product['id'] ?? 0; ?>">

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label" for="name">Product Name *</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="e.g. Ridomil Gold MZ 68 WG (500g)" value="<?php echo htmlspecialchars($edit_product['name'] ?? ''); ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="category">Category *</label>
                    <select name="category" id="category" class="form-control" required>
                        <?php 
                        $cats = ['Fungicide', 'Insecticide', 'Bio-Pesticide', 'Equipment', 'Fertilizer'];
                        $current_cat = $edit_product['category'] ?? 'Fungicide';
                        foreach ($cats as $c) {
                            $sel = ($current_cat === $c) ? 'selected' : '';
                            echo "<option value=\"$c\" $sel>$c</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label" for="target_crop">Target Crops *</label>
                    <input type="text" name="target_crop" id="target_crop" class="form-control" placeholder="e.g. Tomato, Potato, Maize" value="<?php echo htmlspecialchars($edit_product['target_crop'] ?? 'All Crops'); ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="target_disease">Target Disease / Controlled Pest *</label>
                    <input type="text" name="target_disease" id="target_disease" class="form-control" placeholder="e.g. Late Blight, Rust, MLND Vectors" value="<?php echo htmlspecialchars($edit_product['target_disease'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="grid-2">
                <div class="form-group">
                    <label class="form-label" for="price">Price (KSh) *</label>
                    <input type="number" step="0.01" name="price" id="price" class="form-control" placeholder="1650.00" value="<?php echo htmlspecialchars($edit_product['price'] ?? ''); ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label" for="stock_quantity">Available Inventory Stock *</label>
                    <input type="number" name="stock_quantity" id="stock_quantity" class="form-control" placeholder="50" value="<?php echo htmlspecialchars($edit_product['stock_quantity'] ?? '50'); ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="dosage">Recommended Dosage & Application Instructions *</label>
                <input type="text" name="dosage" id="dosage" class="form-control" placeholder="e.g. 50g per 20 Litre knapsack sprayer" value="<?php echo htmlspecialchars($edit_product['dosage'] ?? ''); ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label" for="description">Detailed Description & Benefits *</label>
                <textarea name="description" id="description" class="form-control" rows="3" placeholder="Describe the chemical active ingredient and mode of action..." required><?php echo htmlspecialchars($edit_product['description'] ?? ''); ?></textarea>
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <a href="products.php" class="btn btn-outline">Cancel</a>
                <button type="submit" class="btn btn-primary">
                    <?php echo $edit_product ? 'Save Changes' : 'Create Product'; ?>
                </button>
            </div>
        </form>
    </div>
<?php endif; ?>

<!-- LIST VIEW -->
<div class="card">
    <div class="card-header" style="flex-wrap: wrap; gap: 10px;">
        <h3 class="card-title">Inventory Catalog (<?php echo count($products); ?> Products)</h3>
    </div>

    <!-- Filter Form -->
    <form method="GET" action="products.php" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
        <select name="category" class="form-control" style="width: auto; min-width: 150px;" onchange="this.form.submit()">
            <option value="">All Categories</option>
            <option value="Fungicide" <?php echo $filter_cat === 'Fungicide' ? 'selected' : ''; ?>>Fungicides</option>
            <option value="Insecticide" <?php echo $filter_cat === 'Insecticide' ? 'selected' : ''; ?>>Insecticides</option>
            <option value="Bio-Pesticide" <?php echo $filter_cat === 'Bio-Pesticide' ? 'selected' : ''; ?>>Bio-Pesticides</option>
            <option value="Equipment" <?php echo $filter_cat === 'Equipment' ? 'selected' : ''; ?>>Equipment</option>
            <option value="Fertilizer" <?php echo $filter_cat === 'Fertilizer' ? 'selected' : ''; ?>>Fertilizers</option>
        </select>

        <input type="text" name="q" class="form-control" placeholder="Search product name, crop, or target disease..." value="<?php echo htmlspecialchars($search_q); ?>" style="flex: 1; min-width: 200px;">

        <button type="submit" class="btn btn-outline btn-sm">Filter</button>
        <?php if (!empty($filter_cat) || !empty($search_q)): ?>
            <a href="products.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151;">Reset</a>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Category</th>
                    <th>Target Disease</th>
                    <th>Price (KSh)</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-muted); padding: 25px;">
                            No products found matching query.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($products as $p): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($p['name']); ?></strong><br>
                                <span style="font-size: 0.78rem; color: var(--text-muted);">Crops: <?php echo htmlspecialchars($p['target_crop']); ?></span>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo htmlspecialchars($p['category']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($p['target_disease']); ?></td>
                            <td>
                                <strong>KSh <?php echo number_format($p['price'], 2); ?></strong>
                            </td>
                            <td>
                                <span style="font-weight: 600; color: <?php echo $p['stock_quantity'] > 10 ? 'var(--success)' : ($p['stock_quantity'] > 0 ? 'var(--warning)' : 'var(--danger)'); ?>;">
                                    <?php echo (int)$p['stock_quantity']; ?> units
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <a href="products.php?action=edit&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline">
                                        Edit
                                    </a>
                                    <a href="products.php?action=delete&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this product from catalog?');">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
