<?php
// crop_disease_control/admin/dashboard.php
// Administrator Portal Dashboard - Comprehensive Central Command

$depth = 1;
$base_prefix = '../';
$page_title = "Admin Dashboard";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

$current_user = current_user();

// Fetch system analytics
$total_farmers = 0;
$total_scans = 0;
$total_diseases = 0;
$avg_confidence = 0;
$total_products = 0;
$total_orders = 0;
$total_revenue = 0;
$new_messages = 0;
$crop_breakdown = [];
$recent_scans = [];
$recent_orders = [];

try {
    $total_farmers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'farmer'")->fetchColumn();
    $total_scans = (int)$pdo->query("SELECT COUNT(*) FROM predictions")->fetchColumn();
    $total_diseases = (int)$pdo->query("SELECT COUNT(*) FROM diseases")->fetchColumn();
    $avg_confidence = (float)$pdo->query("SELECT AVG(confidence) FROM predictions")->fetchColumn() ?: 0;
    
    // E-commerce stats
    $total_products = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    $total_orders = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
    $total_revenue = (float)$pdo->query("SELECT SUM(total_amount) FROM orders WHERE payment_status = 'Paid'")->fetchColumn() ?: 0;
    $new_messages = (int)$pdo->query("SELECT COUNT(*) FROM contact_messages WHERE status = 'New'")->fetchColumn();

    // Scans by Crop
    $stmt = $pdo->query("
        SELECT crop_type, COUNT(*) as count 
        FROM images 
        GROUP BY crop_type
    ");
    $crop_breakdown = $stmt->fetchAll();

    // Recent Scans
    $stmt = $pdo->query("
        SELECT 
            p.id AS prediction_id,
            p.confidence,
            p.created_at,
            i.image_path,
            i.crop_type,
            u.name AS farmer_name,
            u.county,
            d.disease_name,
            d.severity
        FROM predictions p
        JOIN images i ON p.image_id = i.id
        JOIN users u ON i.user_id = u.id
        JOIN diseases d ON p.disease_id = d.id
        ORDER BY p.created_at DESC
        LIMIT 5
    ");
    $recent_scans = $stmt->fetchAll();

    // Recent Orders
    $stmt_ord = $pdo->query("
        SELECT * FROM `orders` 
        ORDER BY `id` DESC 
        LIMIT 5
    ");
    $recent_orders = $stmt_ord->fetchAll();

} catch (PDOException $e) {
    $error = $e->getMessage();
}

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 15px;">
    <div>
        <h1 style="font-size: 1.8rem; color: var(--primary-dark); margin-bottom: 4px;">
            System Administration Console
        </h1>
        <p style="color: var(--text-muted); font-size: 0.95rem;">
            Logged in as <strong><?php echo htmlspecialchars($current_user['name']); ?></strong> &bull; Complete 8+ Module Management Suite
        </p>
    </div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
        <a href="reports.php" class="btn btn-outline btn-sm">Outbreak Reports</a>
        <a href="messages.php" class="btn btn-outline btn-sm">
            Inquiries <?php echo $new_messages > 0 ? "({$new_messages} New)" : ""; ?>
        </a>
        <a href="orders.php" class="btn btn-primary btn-sm">Manage Orders</a>
    </div>
</div>

<!-- Admin KPI Summary Cards -->
<div class="grid-4" style="margin-bottom: 20px;">
    <div class="stat-card">
        <div class="stat-icon" style="background:#e0f2fe; color:#0284c7; font-weight:bold; font-size: 0.85rem;">USR</div>
        <div>
            <div class="stat-val"><?php echo $total_farmers; ?></div>
            <div class="stat-label">Registered Farmers</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fef3c7; color:#d97706; font-weight:bold; font-size: 0.85rem;">SCN</div>
        <div>
            <div class="stat-val"><?php echo $total_scans; ?></div>
            <div class="stat-label">Leaf Diagnoses Run</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7; color:#16a34a; font-weight:bold; font-size: 0.85rem;">PRD</div>
        <div>
            <div class="stat-val"><?php echo $total_products; ?></div>
            <div class="stat-label">Remedy Products</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#f3e8ff; color:#9333ea; font-weight:bold; font-size: 0.85rem;">REV</div>
        <div>
            <div class="stat-val">KSh <?php echo number_format($total_revenue, 0); ?></div>
            <div class="stat-label">Paid Sales Revenue</div>
        </div>
    </div>
</div>

<!-- All 8+ Admin Control Functions Grid -->
<div class="card" style="margin-bottom: 24px;">
    <div class="card-header">
        <h2 class="card-title" style="font-size: 1.25rem;">Administrator System Functions (All Modules)</h2>
        <span class="badge badge-info">8+ Active Capabilities</span>
    </div>
    
    <div class="grid-4" style="gap: 14px;">
        <a href="diseases.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">1. Disease Catalog</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Manage crop symptoms, treatments, preventions & severity.</div>
        </a>

        <a href="products.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">2. Manage Products</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Add, edit pesticides, fungicides, inventory stock & prices.</div>
        </a>

        <a href="orders.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">3. Update Orders</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Manage farmer orders, dispatch status & M-Pesa payments.</div>
        </a>

        <a href="scans.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">4. Scan Audit Logs</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Audit all nationwide AI diagnostic predictions & leaf photos.</div>
        </a>

        <a href="users.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">5. User Administration</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">View farmers, toggle roles between Farmer and Admin.</div>
        </a>

        <a href="messages.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">6. Support Inquiries</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Answer incoming farmer questions & extension inquiries.</div>
        </a>

        <a href="reports.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">7. Outbreak Analytics</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Review disease outbreaks by Kenyan county & remedy sales.</div>
        </a>

        <a href="settings.php" style="text-decoration: none; color: inherit; display: block; border: 1px solid var(--border); border-radius: 6px; padding: 14px; background: #fff; transition: border-color 0.2s;">
            <div style="font-weight: 700; color: var(--primary-dark); margin-bottom: 4px;">8. System Settings</div>
            <div style="font-size: 0.8rem; color: var(--text-muted);">Configure M-Pesa till, delivery fees & database tools.</div>
        </a>
    </div>
</div>

<!-- Recent Orders & Recent Scans Side-by-Side -->
<div class="grid-2" style="margin-bottom: 24px;">
    <!-- Recent Orders -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Recent Chemical Orders</h3>
            <a href="orders.php" class="btn btn-sm btn-outline">View All</a>
        </div>
        <?php if (empty($recent_orders)): ?>
            <p style="color: var(--text-muted); font-size: 0.9rem;">No orders placed yet.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th>Recipient</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_orders as $ro): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($ro['order_number']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($ro['shipping_name']); ?></td>
                                <td>KSh <?php echo number_format($ro['total_amount'], 2); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $ro['order_status'] === 'Delivered' ? 'healthy' : 'info'; ?>">
                                        <?php echo htmlspecialchars($ro['order_status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Scans by Crop Distribution -->
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Crop Scan Distribution</h3>
            <a href="scans.php" class="btn btn-sm btn-outline">All Scans</a>
        </div>
        <?php if (empty($crop_breakdown)): ?>
            <p style="color: var(--text-muted); font-size: 0.9rem;">No scan data recorded yet.</p>
        <?php else: ?>
            <div style="display: flex; flex-direction: column; gap: 12px;">
                <?php foreach ($crop_breakdown as $cb): 
                    $pct = $total_scans > 0 ? round(($cb['count'] / $total_scans) * 100, 1) : 0;
                ?>
                    <div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.9rem; margin-bottom: 4px;">
                            <span><strong><?php echo htmlspecialchars($cb['crop_type']); ?></strong></span>
                            <span><?php echo $cb['count']; ?> scans (<?php echo $pct; ?>%)</span>
                        </div>
                        <div style="background: #e2e8f0; height: 8px; border-radius: 9999px; overflow: hidden;">
                            <div style="background: var(--primary); width: <?php echo $pct; ?>%; height: 100%;"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
