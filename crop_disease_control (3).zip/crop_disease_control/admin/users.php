<?php
// crop_disease_control/admin/users.php
// Administrator User Management (Farmers and Admins)

$depth = 1;
$base_prefix = '../';
$page_title = "Manage Users";

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin('../login.php');

$current_user = current_user();

// Handle Role Switch
if (isset($_GET['toggle_role'])) {
    $target_id = (int)$_GET['toggle_role'];
    if ($target_id === $current_user['id']) {
        set_flash('danger', 'You cannot change your own administrator role.');
    } else {
        try {
            $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
            $stmt->execute([$target_id]);
            $user_row = $stmt->fetch();
            if ($user_row) {
                $new_role = ($user_row['role'] === 'admin') ? 'farmer' : 'admin';
                $stmt_up = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
                $stmt_up->execute([$new_role, $target_id]);
                set_flash('success', "User role updated to '{$new_role}'.");
            }
        } catch (PDOException $e) {
            set_flash('danger', 'Error updating role: ' . $e->getMessage());
        }
    }
    header("Location: users.php");
    exit;
}

// Handle Delete User
if (isset($_GET['delete_id'])) {
    $del_id = (int)$_GET['delete_id'];
    if ($del_id === $current_user['id']) {
        set_flash('danger', 'You cannot delete your own logged-in account.');
    } else {
        try {
            $stmt_del = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt_del->execute([$del_id]);
            set_flash('success', 'User and associated data removed successfully.');
        } catch (PDOException $e) {
            set_flash('danger', 'Error deleting user: ' . $e->getMessage());
        }
    }
    header("Location: users.php");
    exit;
}

// Handle Add User Form (Plaintext passwords)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $county = sanitize($_POST['county'] ?? 'Nakuru');
    $role = sanitize($_POST['role'] ?? 'farmer');
    $password = $_POST['password'] ?? '';

    if (empty($name) || empty($email) || empty($password)) {
        set_flash('danger', 'Name, Email, and Password are required.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        set_flash('danger', 'Invalid email address provided.');
    } else {
        try {
            $chk = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $chk->execute([$email]);
            if ($chk->fetch()) {
                set_flash('danger', 'A user with this email address already exists.');
            } else {
                // Store password in plain text as requested
                $ins = $pdo->prepare("INSERT INTO users (name, email, password, phone, county, role) VALUES (?, ?, ?, ?, ?, ?)");
                $ins->execute([$name, $email, $password, $phone, $county, $role]);
                set_flash('success', "Account for {$name} created successfully.");
                header("Location: users.php");
                exit;
            }
        } catch (PDOException $e) {
            set_flash('danger', 'Database error: ' . $e->getMessage());
        }
    }
}

// Fetch users with scan counts
$search_q = sanitize($_GET['q'] ?? '');
$filter_role = sanitize($_GET['role'] ?? '');

$sql = "
    SELECT 
        u.*,
        COUNT(i.id) AS scan_count
    FROM users u
    LEFT JOIN images i ON u.id = i.user_id
    WHERE 1=1
";
$params = [];

if (!empty($search_q)) {
    $sql .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.county LIKE ?)";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
    $params[] = "%{$search_q}%";
}
if (!empty($filter_role)) {
    $sql .= " AND u.role = ?";
    $params[] = $filter_role;
}

$sql .= " GROUP BY u.id ORDER BY u.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users_list = $stmt->fetchAll();

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
    <div>
        <h1 class="card-title" style="font-size: 1.6rem;">User Management</h1>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">
            Manage registered farmers, agricultural officers, and platform administrators.
        </p>
    </div>
    <button onclick="document.getElementById('newUserBox').style.display = document.getElementById('newUserBox').style.display === 'none' ? 'block' : 'none';" class="btn btn-primary btn-sm">
        Add New User
    </button>
</div>

<!-- Add User Box (collapsible) -->
<div id="newUserBox" class="card" style="display: none; border-top: 4px solid var(--primary); max-width: 750px; margin: 0 auto 24px auto;">
    <div class="card-header">
        <h3 class="card-title">Create New User Account</h3>
    </div>
    <form method="POST" action="users.php">
        <input type="hidden" name="add_user" value="1">
        
        <div class="grid-2">
            <div class="form-group">
                <label class="form-label" for="name">Full Name *</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="e.g. Samuel Kariuki" required>
            </div>
            <div class="form-group">
                <label class="form-label" for="email">Email Address *</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="user@cropai.ke" required>
            </div>
        </div>

        <div class="grid-3">
            <div class="form-group">
                <label class="form-label" for="phone">Phone Number</label>
                <input type="tel" name="phone" id="phone" class="form-control" placeholder="+254 700 000 000">
            </div>
            <div class="form-group">
                <label class="form-label" for="county">County</label>
                <input type="text" name="county" id="county" class="form-control" value="Nakuru">
            </div>
            <div class="form-group">
                <label class="form-label" for="role">System Role *</label>
                <select name="role" id="role" class="form-control">
                    <option value="farmer">Farmer</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label" for="password">Password (Plaintext) *</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="Enter password" required>
        </div>

        <div style="display: flex; gap: 10px; justify-content: flex-end;">
            <button type="button" onclick="document.getElementById('newUserBox').style.display='none'" class="btn btn-outline">Cancel</button>
            <button type="submit" class="btn btn-primary">Create Account</button>
        </div>
    </form>
</div>

<!-- Users Table Card -->
<div class="card">
    <div class="card-header" style="flex-wrap: wrap; gap: 10px;">
        <h3 class="card-title">Registered Accounts (<?php echo count($users_list); ?> Total)</h3>
    </div>

    <!-- Filter Bar -->
    <form method="GET" action="users.php" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
        <select name="role" class="form-control" style="width: auto; min-width: 140px;" onchange="this.form.submit()">
            <option value="">All Roles</option>
            <option value="farmer" <?php echo $filter_role === 'farmer' ? 'selected' : ''; ?>>Farmers Only</option>
            <option value="admin" <?php echo $filter_role === 'admin' ? 'selected' : ''; ?>>Admins Only</option>
        </select>

        <input type="text" name="q" class="form-control" placeholder="Search by name, email or county..." value="<?php echo htmlspecialchars($search_q); ?>" style="flex: 1; min-width: 200px;">

        <button type="submit" class="btn btn-outline btn-sm">Search</button>
        <?php if (!empty($filter_role) || !empty($search_q)): ?>
            <a href="users.php" class="btn btn-sm" style="background:#e5e7eb; color:#374151;">Reset</a>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>County / Location</th>
                    <th>Role</th>
                    <th>Scans Logged</th>
                    <th>Registered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users_list)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 25px;">
                            No user accounts found matching query.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users_list as $u): ?>
                        <tr>
                            <td>#<?php echo $u['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($u['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                            <td><?php echo htmlspecialchars($u['county'] ?: 'Kenya'); ?></td>
                            <td>
                                <span class="badge badge-<?php echo $u['role'] === 'admin' ? 'moderate' : 'healthy'; ?>">
                                    <?php echo ucfirst($u['role']); ?>
                                </span>
                            </td>
                            <td>
                                <span style="font-weight: 600;"><?php echo (int)$u['scan_count']; ?></span>
                            </td>
                            <td style="font-size: 0.85rem; color: var(--text-muted);">
                                <?php echo date('M d, Y', strtotime($u['created_at'])); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <?php if ($u['id'] !== $current_user['id']): ?>
                                        <a href="users.php?toggle_role=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline" title="Switch role between Farmer and Admin">
                                            Make <?php echo $u['role'] === 'admin' ? 'Farmer' : 'Admin'; ?>
                                        </a>
                                        <a href="users.php?delete_id=<?php echo $u['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirmAction('Delete this user account? All uploaded images and predictions will also be deleted.');">
                                            Delete
                                        </a>
                                    <?php else: ?>
                                        <span style="font-size: 0.8rem; color: var(--text-muted);">(You)</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
